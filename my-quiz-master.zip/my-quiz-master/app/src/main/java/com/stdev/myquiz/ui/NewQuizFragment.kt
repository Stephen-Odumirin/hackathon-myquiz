package com.stdev.myquiz.ui

import android.app.Activity.RESULT_OK
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.google.android.gms.tasks.Continuation
import com.google.android.gms.tasks.Task
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.UploadTask
//import com.stdev.myquiz.NewQuizFragmentDirections
import com.stdev.myquiz.R
import com.stdev.myquiz.models.QuizListModel
import java.util.*
import kotlin.collections.HashMap

class NewQuizFragment : Fragment(), AdapterView.OnItemSelectedListener {

    //firebase
    private lateinit var firebaseFirestore: FirebaseFirestore
    private lateinit var navController: NavController


    private lateinit var newQuizTitle: TextInputEditText
    private lateinit var newQuizDescription: TextInputEditText
    private lateinit var newQuizImage: ImageView
    private lateinit var newQuizLevel: Spinner
    private lateinit var newQuizVisibility: Spinner
    private lateinit var newQuizType : Spinner
    private lateinit var newQuizButton: MaterialButton
    private lateinit var newQuizFeedback: TextView
    private lateinit var newQuizTime : TextInputEditText
    private lateinit var newQuizTimeLayout : TextInputLayout
    private lateinit var newQuizPdf : MaterialButton
    private lateinit var newQuizProgress : ProgressBar

    //Variables
    private var selectedLevel = ""
    private var selectedVisibility = ""
    private var selectedQuizType = "Quiz Mode"
    private var quizId = ""
    private var userId = ""


    private var imagePath: Uri? = null
    private var pdfPath : Uri? = null
    private var storageReference: StorageReference? = null
    private var firebaseStorage: FirebaseStorage? = null
    private var firebaseAuth: FirebaseAuth? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_new_quiz, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        firebaseFirestore = FirebaseFirestore.getInstance()
        firebaseAuth = FirebaseAuth.getInstance()

        userId = firebaseAuth!!.currentUser?.uid!!

        navController = Navigation.findNavController(view)
        firebaseStorage = FirebaseStorage.getInstance()
        storageReference = FirebaseStorage.getInstance().reference

        newQuizTitle = view.findViewById(R.id.new_quiz_title)
        newQuizDescription = view.findViewById(R.id.new_quiz_description)
        newQuizImage = view.findViewById(R.id.new_quiz_image)
        newQuizLevel = view.findViewById(R.id.new_quiz_level)
        newQuizVisibility = view.findViewById(R.id.new_quiz_visibility)
        newQuizButton = view.findViewById(R.id.new_quiz_button)
        newQuizFeedback = view.findViewById(R.id.new_quiz_feedback)
        newQuizTime = view.findViewById(R.id.new_quiz_time)
        newQuizTimeLayout = view.findViewById(R.id.textInputLayout3)
        newQuizPdf = view.findViewById(R.id.new_quiz_pdf)
        newQuizProgress = view.findViewById(R.id.new_quiz_progress)

        val levelSpinner: Spinner = view.findViewById(R.id.new_quiz_level)
        val visibilitySpinner: Spinner = view.findViewById(R.id.new_quiz_visibility)
        val quizTypeSpinner : Spinner = view.findViewById(R.id.new_quiz_type)

        ArrayAdapter.createFromResource(
            requireContext(),
            R.array.quiz_level, android.R.layout.simple_spinner_item
        )
            .also { adapter ->
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                levelSpinner.adapter = adapter
            }
        ArrayAdapter.createFromResource(
            requireContext(),
            R.array.quiz_visibility, android.R.layout.simple_spinner_item
        )
            .also { adapter ->
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                visibilitySpinner.adapter = adapter
            }

        ArrayAdapter.createFromResource(
            requireContext(),
            R.array.quiz_type, android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            quizTypeSpinner.adapter = adapter
        }

        visibilitySpinner.onItemSelectedListener = this
        levelSpinner.onItemSelectedListener = this
        quizTypeSpinner.onItemSelectedListener = this

        newQuizImage.setOnClickListener {
            val galleryIntent = Intent()
            galleryIntent.type = "image/*"
            galleryIntent.action = Intent.ACTION_GET_CONTENT
            startActivityForResult(
                Intent.createChooser(galleryIntent, "Select Quiz Image"),
                QUIZ_GALLERY_PICK
            )
        }

        newQuizPdf.setOnClickListener{
            val pdfIntent = Intent()
            val mineTypes = arrayListOf("image/jpeg", "audio/midi","image/png","application/pdf","text/plain")
            pdfIntent.type = "*/*"
            pdfIntent.action = Intent.ACTION_GET_CONTENT
            pdfIntent.putExtra(Intent.EXTRA_MIME_TYPES,mineTypes)
            startActivityForResult(Intent.createChooser(pdfIntent,"Select PDF"),QUIZ_PDF_PICK)
        }

        newQuizButton.setOnClickListener {
            createQuiz()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if(resultCode == RESULT_OK && data != null){
           if(requestCode == QUIZ_GALLERY_PICK){
               imagePath = data.data
               try {
                   val bitmap = MediaStore.Images.Media.getBitmap(context?.contentResolver, imagePath)
                   newQuizImage.setImageBitmap(bitmap)
               } catch (error: Exception) {
                   Toast.makeText(context, "${error.message}", Toast.LENGTH_SHORT).show()
               }
           } else if (requestCode == QUIZ_PDF_PICK){
               pdfPath = data.data
           }
        }
    }

    private fun createQuiz() {
        val title = newQuizTitle.editableText.toString()
        val description = newQuizDescription.editableText.toString()
        val image = "null"
        val level = selectedLevel
        val visibility = selectedVisibility
        val quizType = selectedQuizType
        val examTime = newQuizTime.editableText?.toString()?.toLong() ?: 0L

        if (title.isNotEmpty() && description.isNotEmpty()) {

            newQuizProgress.visibility = View.VISIBLE

            quizId = firebaseFirestore.collection("quizlist").document().id
            val timestamp = System.currentTimeMillis()

            val quizListModel = QuizListModel(quiz_id = quizId, name = title,description =  description,image = "null",level =  level,visibility =  visibility,
                creator = userId,timestamp = timestamp, quizType = quizType, quizTime = examTime)

            Log.i("NewQuizFragment", "Quiz List Model -> ${quizListModel.toString()} ")
            firebaseFirestore.collection("quizlist").document(quizId).set(quizListModel)
                .addOnCompleteListener {
                    if (it.isSuccessful) {
                        newQuizProgress.visibility = View.INVISIBLE
                        uploadImage()
                        uploadPdf()
                        val action = NewQuizFragmentDirections.actionNewQuizFragmentToAddQuizListFragment()
                        action.quizId = quizId
                        action.quizType = selectedQuizType
                        navController.navigate(action)
                    } else {
                        newQuizProgress.visibility = View.GONE
                        newQuizFeedback.text = "Exception => ${it.exception?.message}"
                        Toast.makeText(context, "Error -> ${it.exception?.message}",Toast.LENGTH_SHORT).show()

                    }
                }
        } else {
            newQuizProgress.visibility = View.GONE
            newQuizTitle.error = "Enter Title"
            newQuizDescription.error = "Enter Description"
        }
    }

    private fun uploadPdf(){
        if(pdfPath != null){
            val ref = storageReference?.child("quiz_pdf/${UUID.randomUUID()}")
            val uploadTask = ref?.putFile(pdfPath!!)

            uploadTask?.continueWithTask(Continuation<UploadTask.TaskSnapshot, Task<Uri>> { task ->
                if (!task.isSuccessful) {
                    task.exception?.let {
                        throw it
                    }
                }
                return@Continuation ref.downloadUrl
            })?.addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val downloadUrl = task.result
                    addPdfToDatabase(downloadUrl.toString())
                }
            }
        }
    }

    private fun uploadImage() {
        if (imagePath != null) {
            val ref = storageReference?.child("quiz_cover/${UUID.randomUUID()}")
            val uploadTask = ref?.putFile(imagePath!!)

            uploadTask?.continueWithTask(Continuation<UploadTask.TaskSnapshot, Task<Uri>> { task ->
                if (!task.isSuccessful) {
                    task.exception?.let {
                        throw it
                    }
                }
                return@Continuation ref.downloadUrl
            })?.addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val downloadUrl = task.result
                    addImageToDatabase(downloadUrl.toString())
                }
            }
        }
    }

    private fun addImageToDatabase(uri: String) {
        val data = HashMap<String, Any>()
        data["image"] = uri

        firebaseFirestore.collection("quizlist").document(quizId).update(data)
            .addOnSuccessListener {
                Log.i("NewQuizFragment", "Success Uploading Image")
            }.addOnFailureListener {
                Log.i("NewQuizFragment","Error Uploading Image -> ${it.message}")
        }
    }

    private fun addPdfToDatabase(uri : String){
        val data = HashMap<String,Any>()
        data["pdf"] = uri
        firebaseFirestore.collection("quizlist").document(quizId).update(data).addOnSuccessListener {
            Log.i("NewQuizFragment","Success Uploading Pdf")
        }.addOnFailureListener{
            Log.i("NewQuizFragment", "Error Uploading Pdf -> ${it.message}")
        }
    }

    override fun onNothingSelected(parent: AdapterView<*>?) {
        Log.i("NewQuizFragment", "You Selected Nothing ")
    }

    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        val spin: Spinner = parent as Spinner
        val spin2: Spinner = parent as Spinner
        val spin3 : Spinner = parent as Spinner

        if (spin.id == R.id.new_quiz_level) {
            selectedLevel = spin.getItemAtPosition(position) as String
            Log.i("NewQuizFragment", "You Selected level => $selectedLevel ")
        }
        else if (spin2.id == R.id.new_quiz_visibility) {
            selectedVisibility = spin2.getItemAtPosition(position) as String
            Log.i("NewQuizFragment", "You Selected Visibility => $selectedVisibility ")
        }
        else if(spin3.id == R.id.new_quiz_type){
            selectedQuizType = spin3.getItemAtPosition(position) as String
            if(selectedQuizType == "Exam Mode" || selectedQuizType == "Practice Mode"){
                newQuizTime.visibility = View.VISIBLE
                newQuizTimeLayout.visibility = View.VISIBLE

            }else{
                newQuizTime.visibility = View.INVISIBLE
                newQuizTimeLayout.visibility = View.INVISIBLE
            }
            Log.i("NewQuizFragment","You Selected Quiz Type => $selectedQuizType")
        }
    }

    companion object {
        const val QUIZ_GALLERY_PICK = 1
        const val QUIZ_PDF_PICK = 2
    }
}


