package com.stdev.myquiz.ui

import android.os.Bundle
import android.os.CountDownTimer
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.OnBackPressedCallback

import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.navigation.fragment.NavHostFragment
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.MetadataChanges
import com.google.firebase.firestore.ktx.firestoreSettings
import com.stdev.myquiz.R
import com.stdev.myquiz.models.QuestionModel

class QuizFragment : Fragment(), View.OnClickListener {

    private lateinit var firebaseFirestore: FirebaseFirestore
    private lateinit var firebaseAuth: FirebaseAuth
    private var navController: NavController? = null

    private var quizId = ""
    private var quizName = ""
    private var quizImage = ""
    private var username = ""
    private var userimage = ""

    private lateinit var textView: TextView
    private lateinit var quizTitle: TextView
    private lateinit var quizErrorImage : ImageView
    private lateinit var quizQuestionNumber: TextView
    private lateinit var quizQuestionTime: TextView
    private lateinit var quizQuestion: TextView
    private lateinit var quizOptionOne: TextView
    private lateinit var quizOptionTwo: TextView
    private lateinit var quizOptionThree: TextView
    private lateinit var quizOptionFour: TextView
    private lateinit var quizOptionFive : TextView
    private lateinit var nextButton: MaterialButton
    private lateinit var quizFeedback: TextView
    private lateinit var quizProgress: ProgressBar


    private var countDownTimer: CountDownTimer? = null
    private var canAnswer = false
    private var currentQuestion = 0
    private var currentUserId = ""

    private var correctAnswers = 0
    private var wrongAnswers = 0
    private var notAnswered = 0
    private var percent = 0

    private var answers : MutableList<String> = ArrayList()

    //firebase Data
    private var totalQuestionsToAnswer = 0L
    private var allQuestionsList :List<QuestionModel> = ArrayList()
    //private val questionsToAnswer: MutableList<QuestionModel> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_quiz, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        firebaseAuth = FirebaseAuth.getInstance()
        navController = Navigation.findNavController(view)
        firebaseFirestore = FirebaseFirestore.getInstance()

        //Check if the user is null
        currentUserId = firebaseAuth.currentUser?.uid!!

        (activity as AppCompatActivity).supportActionBar?.setDisplayHomeAsUpEnabled(false)

        //Initialise Views
        initViews(view)

        //Get Quiz Id
        quizId = QuizFragmentArgs.fromBundle(requireArguments()).quizid
        totalQuestionsToAnswer = QuizFragmentArgs.fromBundle(requireArguments()).totalQuestions
        quizName = QuizFragmentArgs.fromBundle(requireArguments()).quizName

        //Load some stuffs
        loadSomeStuffs()

        //Load Questions From Firebase
        loadQuestionsFromFirebase()

        //Set Options Click listener
        quizOptionOne.setOnClickListener(this)
        quizOptionTwo.setOnClickListener(this)
        quizOptionThree.setOnClickListener(this)
        quizOptionFour.setOnClickListener(this)
        quizOptionFive.setOnClickListener(this)
        nextButton.setOnClickListener(this)

        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner,object : OnBackPressedCallback(true){
            override fun handleOnBackPressed() {
                MaterialAlertDialogBuilder(requireContext())
                    .setMessage("Exiting this Quiz would score you 0 % automatically\nAre you sure you want to continue ? ")
                    .setNegativeButton("Stay"){_,_->}
                    .setPositiveButton("Exit"){_,_->
                       submitResults()
                    }.show()
            }

        })
    }

    private fun loadSomeStuffs() {
        firebaseFirestore.collection("quizlist").document(quizId).get().addOnCompleteListener {
            if(it.isSuccessful){
                quizImage = it.result.get("image") as String? ?: "null"
            }

        }.addOnFailureListener {
            quizImage = "Error -> ${it.message}"
        }

        firebaseFirestore.collection("users").document(currentUserId).get().addOnCompleteListener{
            username = it.result.get("name") as String? ?: "null"
            userimage = it.result.get("imageUrl") as String? ?: "null"
        }.addOnFailureListener {
            username = "Error -> ${it.message}"
        }

        showToast(requireContext(), "username -> $username \nuserimage -> $userimage \nquizImage -> $quizImage")
    }

    private fun loadQuestionsFromFirebase() {

        if(totalQuestionsToAnswer != 0L) {
            firebaseFirestore.collection("quizlist").document(quizId).collection("Questions").get()
                .addOnSuccessListener {
                    allQuestionsList = it.toObjects(QuestionModel::class.java)
                    //pickQuestions()
                    loadUI()
                    Log.i("QuizFragment", "Success => $allQuestionsList")
                }.addOnFailureListener {
                    quizTitle.text = "Error Loading Data"
                    Log.i("QuizFragment", "Error => ${it?.message}")
                }
        }else{
            //Show Error Screen
            textView.visibility = View.VISIBLE
            quizErrorImage.visibility = View.VISIBLE
        }
    }

    private fun initViews(view: View) {

        textView = view.findViewById(R.id.quiz_text_error)
        quizErrorImage = view.findViewById(R.id.quiz_error_image)

        quizTitle = view.findViewById(R.id.new_quiz_title)
        quizQuestion = view.findViewById(R.id.quiz_question)
        quizOptionOne = view.findViewById(R.id.quiz_option_one)
        quizOptionTwo = view.findViewById(R.id.quiz_option_two)
        quizOptionThree = view.findViewById(R.id.quiz_option_three)
        quizOptionFour = view.findViewById(R.id.quiz_option_four)
        quizOptionFive = view.findViewById(R.id.quiz_option_five)
        nextButton = view.findViewById(R.id.quiz_next_button)
        quizQuestionTime = view.findViewById(R.id.quiz_question_time)
        quizQuestionNumber = view.findViewById(R.id.quiz_question_number)
        quizFeedback = view.findViewById(R.id.quiz_feedback)
        quizProgress = view.findViewById(R.id.quiz_question_progress)
    }

    private fun loadUI() {
        //Enable Questions
        enableOptions()
        //Load Question
        loadQuestion(1)
    }

    private fun loadQuestion(questionNumber: Int) {
        //Set Question Number
        quizQuestionNumber.text = questionNumber.toString()
        //load Question Text
        quizQuestion.text = allQuestionsList[questionNumber - 1].question

        //load Options
        quizOptionOne.text = allQuestionsList[questionNumber - 1].option_a
        quizOptionTwo.text = allQuestionsList[questionNumber - 1].option_b

        val option_c = allQuestionsList[questionNumber -1].option_c
        val option_d = allQuestionsList[questionNumber -1].option_d
        val option_e = allQuestionsList[questionNumber -1].option_e

        if(option_c == "null" || option_c == "" || option_c.isNullOrBlank()){
            quizOptionThree.visibility = View.INVISIBLE
        }else{
            quizOptionThree.visibility = View.VISIBLE
            quizOptionThree.text = option_c
        }
        if(option_d == "null" || option_d == "" || option_d.isNullOrBlank()){
            quizOptionFour.visibility = View.INVISIBLE
        }else{
            quizOptionFour.visibility = View.VISIBLE
            quizOptionFour.text = option_d
        }
        if (option_e == "null" || option_e == "" || option_e.isNullOrBlank()){
            quizOptionFive.visibility = View.INVISIBLE
        }else {
            quizOptionFive.visibility = View.VISIBLE
            quizOptionFive.text = option_e
        }

        //Question loaded , set can answer
        canAnswer = true
        currentQuestion = questionNumber

        //Start Question Timer
        startTimer(questionNumber)
    }

    private fun startTimer(questionNumber: Int) {
        //Set Question Timer
        val timeToAnswer = allQuestionsList[questionNumber - 1].timer ?: 10L
        quizQuestionTime.text = timeToAnswer.toString()

        quizProgress.visibility = View.VISIBLE

        //Start CountDown
        countDownTimer = object : CountDownTimer(timeToAnswer.times(1000), 10) {
            override fun onFinish() {
                context?.let {
                    canAnswer = false

                    quizFeedback.text = "Time Up! No answer was submitted"
                    quizFeedback.setTextColor(resources.getColor(R.color.red, null)) //todo don't know why this is crashing my app
                    notAnswered++
                    showNextButton()
                }
            }

            override fun onTick(millisUntilFinished: Long) {
                quizQuestionTime.text = "${millisUntilFinished / 1000} "
                val percent = millisUntilFinished / (timeToAnswer * 10)
                quizProgress.progress = percent.toInt()
            }

        }

        countDownTimer?.start()
    }

    private fun enableOptions() {
        quizOptionOne.visibility = View.VISIBLE
        quizOptionTwo.visibility = View.VISIBLE
        quizOptionThree.visibility = View.VISIBLE
        quizOptionFour.visibility = View.VISIBLE
        quizOptionFive.visibility = View.VISIBLE

        //Enable Option Buttons
        quizOptionOne.isEnabled = true
        quizOptionTwo.isEnabled = true
        quizOptionThree.isEnabled = true
        quizOptionFour.isEnabled = true
        quizOptionFive.isEnabled = true

        //Hide Feedback and next Button
        quizFeedback.visibility = View.INVISIBLE
        nextButton.visibility = View.INVISIBLE
        nextButton.isEnabled = false
    }

    private fun disableOptions(){
        quizOptionOne.isEnabled = false
        quizOptionTwo.isEnabled = false
        quizOptionThree.isEnabled = false
        quizOptionFour.isEnabled =  false
        quizOptionFive.isEnabled = false
    }

//    private fun pickQuestions() {
//        for (i in 0 until totalQuestionsToAnswer) {
//            val randomNumber = getRandomInt(0, allQuestionsList.size)
//            allQuestionsList[randomNumber].let { questionsToAnswer.add(it) }
//            //allQuestionsList.removeAt(randomNumber)
//
//        }
//    }

//    private fun getRandomInt(min: Int, max: Int): Int {
//        return (Math.random() * (max - min)).toInt() + min
//    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.quiz_option_one -> {
                verifyAnswer(quizOptionOne)
            }
            R.id.quiz_option_two -> {
                verifyAnswer(quizOptionTwo)
            }
            R.id.quiz_option_three -> {
                verifyAnswer(quizOptionThree)
            }
            R.id.quiz_option_four -> {
                verifyAnswer(quizOptionFour)
            }
            R.id.quiz_option_five -> {
                verifyAnswer(quizOptionFive)
            }
            R.id.quiz_next_button ->
                if (currentQuestion == totalQuestionsToAnswer.toInt()) {
                    submitResults()
                } else {
                    currentQuestion++
                    loadQuestion(currentQuestion)
                    resetOptions()
                }
        }
    }

    private fun submitResults() {
        Log.i("QuizFragment", "submitResults: Percent ->  ${(correctAnswers * 100) / totalQuestionsToAnswer} ")
        val resultMap = HashMap<String, Any>()
        resultMap["correct"] = correctAnswers
        resultMap["wrong"] = wrongAnswers
        resultMap["unanswered"] = notAnswered
        resultMap["totalQuestions"] = totalQuestionsToAnswer
        resultMap["percent"] = (correctAnswers * 100) / totalQuestionsToAnswer
        resultMap["name"] = username
        resultMap["imageUrl"] = userimage

        val resultMapTwo = HashMap<String, Any>()
        resultMapTwo["quiz_id"] = quizId
        resultMapTwo["quizTitle"] = quizName
        resultMapTwo["quizScore"] = (correctAnswers * 100) / totalQuestionsToAnswer
        resultMapTwo["quizImage"] = quizImage

        firebaseFirestore.collection("quizlist").document(quizId).collection("Results")
            .document(currentUserId)
            .set(resultMap).addOnCompleteListener {
                if (it.isSuccessful) {
                    //Go to the results page
                    val action = QuizFragmentDirections.actionQuizFragmentToResultFragment()
                    action.quizId = quizId
                    firebaseFirestore.collection("users").document(currentUserId)
                        .collection("Results").document(quizId).set(resultMapTwo).addOnSuccessListener {
                            navController?.navigate(action)
                        }.addOnFailureListener {
                            showToast(requireContext(),"Error -> ${it.message}")
                        }
                } else {
                    showToast(requireContext(), "${it.exception?.message}")
                }
            }
    }

    private fun resetOptions() {
        quizOptionOne.background = resources.getDrawable(R.drawable.option_unselected, null)
        quizOptionTwo.background = resources.getDrawable(R.drawable.option_unselected, null)
        quizOptionThree.background = resources.getDrawable(R.drawable.option_unselected, null)
        quizOptionFour.background = resources.getDrawable(R.drawable.option_unselected, null)
        quizOptionFive.background = resources.getDrawable(R.drawable.option_unselected, null)

        quizOptionOne.setTextColor(resources.getColor(R.color.colorLightText, null))
        quizOptionTwo.setTextColor(resources.getColor(R.color.colorLightText, null))
        quizOptionThree.setTextColor(resources.getColor(R.color.colorLightText, null))
        quizOptionFour.setTextColor(resources.getColor(R.color.colorLightText, null))
        quizOptionFive.setTextColor(resources.getColor(R.color.colorLightText, null))

        quizFeedback.visibility = View.INVISIBLE
        nextButton.visibility = View.INVISIBLE
        nextButton.isEnabled = false
    }

    private fun verifyAnswer(selectedAnswer: TextView) {
        if (canAnswer) {
            if (allQuestionsList[currentQuestion - 1].answer?.equals(selectedAnswer.text)!!) {
                selectedAnswer.setTextColor(resources.getColor(R.color.colorDark, null))
                //Correct Answer
                selectedAnswer.background = resources.getDrawable(R.drawable.correct_answer, null)
                correctAnswers++
                //quizFeedback.text = "Correct Answer  \n ${allQuestionsList[currentQuestion - 1].description}"
                //quizFeedback.setTextColor(resources.getColor(R.color.colorPrimary, null))
                Log.d("Quiz Fragment", "verifyAnswer => Correct ")
            } else {
                selectedAnswer.background = resources.getDrawable(R.drawable.wrong_answer, null)
                val correctanswer = allQuestionsList[currentQuestion -1].answer
                when {
                    quizOptionOne.text == correctanswer -> {
                        quizOptionOne.background = resources.getDrawable(R.drawable.correct_answer,null)
                    }
                    quizOptionTwo.text == correctanswer -> {
                        quizOptionTwo.background = resources.getDrawable(R.drawable.correct_answer,null)
                    }
                    quizOptionThree.text == correctanswer -> {
                        quizOptionThree.background = resources.getDrawable(R.drawable.correct_answer,null)
                    }
                    quizOptionFour.text == correctanswer -> {
                        quizOptionFour.background = resources.getDrawable(R.drawable.correct_answer,null)
                    }
                    quizOptionFive.text == correctanswer -> {
                        quizOptionFive.background = resources.getDrawable(R.drawable.correct_answer,null)
                    }
                    //quizFeedback.text = "Wrong Answer \n \n Correct Answer : ${allQuestionsList[currentQuestion - 1].answer} \n ${allQuestionsList[currentQuestion - 1].description}"
                    //quizFeedback.setTextColor(resources.getColor(R.color.colorAccent, null))
                }
                //quizFeedback.text = "Wrong Answer \n \n Correct Answer : ${allQuestionsList[currentQuestion - 1].answer} \n ${allQuestionsList[currentQuestion - 1].description}"
                //quizFeedback.setTextColor(resources.getColor(R.color.colorAccent, null))
                wrongAnswers++
                Log.d("Quiz Fragment", "verifyAnswer => Wrong ")
                }

                canAnswer = false
                //Stop the timer
                countDownTimer?.cancel()
                //Show Next Button
                showNextButton()
        }
    }

    private fun showNextButton() {
        if (currentQuestion == totalQuestionsToAnswer.toInt()) {
            nextButton.text = "Finish"
            nextButton.setTextColor(resources.getColor(R.color.white))
            nextButton.visibility = View.VISIBLE
            nextButton.isEnabled = true
            quizFeedback.visibility = View.VISIBLE

        } else {
            quizFeedback.visibility = View.VISIBLE
            nextButton.visibility = View.VISIBLE
            nextButton.isEnabled = true
        }
    }

    override fun onResume() {
        super.onResume()
        (activity as AppCompatActivity).supportActionBar?.hide()
    }

    override fun onStop() {
        super.onStop()
        (activity as AppCompatActivity).supportActionBar?.show()
    }

}