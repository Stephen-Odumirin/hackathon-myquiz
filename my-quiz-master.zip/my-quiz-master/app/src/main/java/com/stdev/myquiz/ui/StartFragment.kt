package com.stdev.myquiz.ui

/*class StartFragment : Fragment() {

    private lateinit var startProgress : ProgressBar
    private lateinit var startFeedbackText : TextView
    private lateinit var firebaseAuth : FirebaseAuth
    private lateinit var navController : NavController

 override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate thsuper.onStart()e layout for this fragment
        return inflater.inflate(R.layout.fragment_start, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        firebaseAuth = FirebaseAuth.getInstance()
        navController = Navigation.findNavController(view)

        startProgress = view.findViewById(R.id.start_progress)
        startFeedbackText = view.findViewById(R.id.start_feedback)

        startFeedbackText.text = "Checking User Account"
        navController.navigate(R.id.action_startFragment_to_listFragment)
    }

//    override fun onStart() {
//        super.onStart()
//        val currentUser : FirebaseUser? = firebaseAuth.currentUser
//        if (currentUser == null) {
//            startFeedbackText.text = "Creating Account"
//            //Create new account
//            val intent = Intent(activity, OnBoardingActivity::class.java)
//            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
//            startActivity(intent)
//        }else{
//            //Navigate to HomePage
//            startFeedbackText.text = "Logged In"
//            navController.navigate(R.id.action_startFragment_to_listFragment)
//
//        }
//    }

}
*/