package com.stdev.myquiz.ui.calculator

import java.util.*
import kotlin.collections.ArrayList

class ExpressionEvaluation {

    private val operator: Stack<Char> = Stack()

    private val expressionToken: ArrayList<String> = ArrayList()

    private val operand: Stack<String> = Stack()

    private fun isOperator(c: Char): Int {
        return if (c == '+') 1 else if (c == '-') 2 else if (c == '\u00d7') 3 else if (c == '\u00f7') 4 else if (c == '%') 5 else -1
    }

    private fun calculate(x: Double, y: Double, operator: Char): Double {
        if (operator == '+') return x + y else if (operator == '-') return x - y else if (operator == '\u00d7') return x * y else if (operator == '\u00f7') return x / y else if (operator == '%') return x % y
        return 0.0 // Should never reach
    }

    public fun expressionEvaluation(expression: String): Double? {

        //Clearing previous data
        var expression = expression
        expressionToken.clear()
        operand.clear()
        operator.clear()
        if (expression[0] == '-') {
            expression = "0$expression"
        }
        val expressionArr = expression.toCharArray()
        var oper = ""
        return try {
            // Parsing expression into tokens
            for (i in expressionArr.indices) {
                if (isOperator(expressionArr[i]) != -1) {
                    expressionToken.add(oper)
                    oper = ""
                    expressionToken.add(expressionArr[i].toString())
                } else oper += expressionArr[i]
            }
            expressionToken.add(oper)

            // Infix evaluation for every token in the expressionToken list
            for (k in expressionToken) {
                if (isOperator(k[0]) == -1) {
                    operand.push(k)
                } else {
                    if (operator.isEmpty()) {
                        operator.push(k[0])
                    } else {
                        var precedenceOfStackTop = isOperator(operator.peek())
                        val precedenceOfOperator = isOperator(k[0])
                        if (precedenceOfStackTop < precedenceOfOperator) {
                            operator.push(k[0])
                        } else {
                            while (!operator.isEmpty() && precedenceOfStackTop >= precedenceOfOperator) {
                                val val1: Double = java.lang.Double.valueOf(operand.pop())
                                val val2: Double = java.lang.Double.valueOf(operand.pop())
                                val res = calculate(val2, val1, operator.pop())
                                operand.push(res.toString())
                                if (!operator.isEmpty()) precedenceOfStackTop =
                                    isOperator(operator.peek())
                            }
                            operator.push(k[0])
                        }
                    }
                }
            }
            while (!operator.empty()) {
                val val1: Double = java.lang.Double.valueOf(operand.pop())
                val val2: Double = java.lang.Double.valueOf(operand.pop())
                val res = calculate(val2, val1, operator.pop())
                operand.push(res.toString())
            }
            java.lang.Double.valueOf(operand.peek())
        } catch (e: Exception) {
            Double.NaN
        }
    }

    fun getData(){

    }

}