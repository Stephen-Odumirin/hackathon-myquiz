package com.stdev.myquiz.models

data class UserModel(
    var user_id: String? = "null",
    var name: String? = "null",
    var email: String? = "null"
) {
}