package com.stdev.myquiz.ui

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.paging.PagedList
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.firebase.ui.firestore.paging.FirestorePagingAdapter
import com.firebase.ui.firestore.paging.FirestorePagingOptions
import com.firebase.ui.firestore.paging.LoadingState
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.stdev.myquiz.R
import com.stdev.myquiz.models.RatingsModel
import com.stdev.myquiz.viewmodel.QuizListViewModel
import de.hdodenhof.circleimageview.CircleImageView

class DetailsFragment : Fragment(), View.OnClickListener {

    private lateinit var navController: NavController
    private lateinit var firebaseFirestore: FirebaseFirestore
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var quizListViewModel: QuizListViewModel

    //Variables
    private var position = 0
    private var quizid = ""
    private var quizId = ""
    private var quizName = ""
    private var currentUserId = ""
    private var totalQuestions: Long = 0
    private var quizType = ""
    private var quizTime = 0L
    private var quizPdf = ""

    private lateinit var detailImage: ImageView
    private lateinit var detailDescription: TextView
    private lateinit var detailDifficulty: TextView
    private lateinit var detailTitle: TextView
    private lateinit var detailQuestions: TextView
    private lateinit var detailScore: TextView
    private lateinit var detailStartButton: Button
    private lateinit var listView : RecyclerView
    private lateinit var detailPdf : Button

    private var adapter : RatingAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_details, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        navController = Navigation.findNavController(view)
        firebaseAuth = FirebaseAuth.getInstance()
        firebaseFirestore = FirebaseFirestore.getInstance()

        quizId = DetailsFragmentArgs.fromBundle(requireArguments()).quizId

        currentUserId = firebaseAuth.currentUser?.uid!!

        Log.d("DetailsFragment", "onViewCreated: Postion => $position ")

        listView = view.findViewById(R.id.detail_recycler_view)
        detailImage = view.findViewById(R.id.detail_image)
        detailTitle = view.findViewById(R.id.detail_title)
        detailDescription = view.findViewById(R.id.detail_description)
        detailDifficulty = view.findViewById(R.id.detail_difficulty_text)
        detailQuestions = view.findViewById(R.id.detail_total_questions)
        detailStartButton = view.findViewById(R.id.detail_button)
        detailScore = view.findViewById(R.id.detail_last_score)
        detailPdf = view.findViewById(R.id.details_pdf)

        getDetails()

        loadResultData()

        detailPdf.setOnClickListener(this)

        detailStartButton.setOnClickListener(this)

        val config = PagedList.Config.Builder()
            .setInitialLoadSizeHint(5)
            .setPageSize(5)
            .build()

        val listQuery : Query = firebaseFirestore.collection("quizlist").document(quizId).collection("Ratings")
        val listOptions = FirestorePagingOptions.Builder<RatingsModel>()
            .setLifecycleOwner(this)
            .setQuery(listQuery,config,RatingsModel::class.java)
            .build()

        listView.layoutManager = LinearLayoutManager(context)
        adapter = RatingAdapter(listOptions)
        listView.adapter = adapter

    }

    private fun getDetails() {
        firebaseFirestore.collection("quizlist").document(quizId).get()
            .addOnSuccessListener { snapshot ->
                if (snapshot.exists() && snapshot != null) {
                    detailTitle.text = snapshot["name"] as String
                    detailDescription.text = snapshot["description"] as String
                    detailDifficulty.text = snapshot["level"] as String
                    detailQuestions.text = (snapshot["questions"] as Long).toString()
                    showToast(
                        requireContext(),
                        "TestingRatingStuffs DF, \nAvg Rating -> ${snapshot["avgRating"]} , " +
                                "\nnumRating -> ${snapshot["numRating"]}, \ntimesTaken -> ${snapshot["timesTaken"]}" +
                                "\nquizType -> ${snapshot["quizType"]} \n quizTime -> ${snapshot["quizTime"]} \n firebasePdf -> ${snapshot["pdf"]} \n quizPdf -> $quizPdf"
                    )
                    totalQuestions = snapshot["questions"] as Long? ?: 0L
                    quizName = snapshot["name"] as String? ?: "null"
                    quizType = snapshot["quizType"] as String? ?: "null"
                    quizTime = snapshot["quizTime"] as Long? ?: 0L
                    val image = snapshot["image"] as String? ?: "null"
                    if (image != "null") {
                        detailImage.visibility = View.VISIBLE
                        context?.let {
                            Glide.with(it)
                                .load(image)
                                .centerCrop()
                                .placeholder(R.drawable.placeholder_image)
                                .into(detailImage)
                        }
                    }
                    quizPdf = snapshot["pdf"] as String? ?: "null"

                    if(quizPdf != "null" && quizPdf != ""){
                        detailPdf.visibility = View.VISIBLE
                        detailPdf.setOnClickListener{
                            val downloadManager : DownloadManager = context?.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                            val uri = Uri.parse(quizPdf)
                            val request = DownloadManager.Request(uri)
                            request.setTitle("$quizName")
                            request.setDescription("Downloading the attachment file for $quizName...")
                            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                            val path = "$quizName"
                            request.setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS,path)
                            downloadManager.enqueue(request)
                        }
                    }
                }
            }.addOnFailureListener {
                detailTitle.text = "${it.message}"
            }
    }

    private inner class RatingAdapter(options: FirestorePagingOptions<RatingsModel>) :
        FirestorePagingAdapter<RatingsModel, RatingAdapter.RatingViewHolder>(options) {


        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RatingViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.single_rating_list, parent, false)
            return RatingViewHolder(view)
        }

        override fun onBindViewHolder(holder: RatingViewHolder, position: Int, model: RatingsModel) {
            holder.setListData(model.name,model.rating,model.imageUrl,model.comment)
        }

        inner class RatingViewHolder(val view: View) : RecyclerView.ViewHolder(view) {

            internal fun setListData(_username: String?, _rating: Double?, _image: String?, _comment : String? ) {
                val username = view.findViewById<TextView>(R.id.rating_name)
                val rating = view.findViewById<TextView>(R.id.rating_count)
                val image = view.findViewById<CircleImageView>(R.id.rating_image)
                val comment = view.findViewById<TextView>(R.id.rating_comment)

                username.text = "$_username"
                rating.text = "$_rating"
                comment.text = "$_comment"
                if (_image != "null") {
                    image.visibility = View.VISIBLE
                    Glide.with(itemView.context)
                        .load(_image)
                        .centerCrop()
                        .placeholder(R.drawable.placeholder_image)
                        .into(image)
                }

            }
        }

        override fun onLoadingStateChanged(state: LoadingState) {
            super.onLoadingStateChanged(state)
            when (state) {
                LoadingState.LOADED -> Log.i(
                    "PopularQuizAdapter",
                    "onLoadingStateChanged: Loaded $itemCount"
                )
                LoadingState.LOADING_INITIAL -> Log.i(
                    "PopularQuizAdapter",
                    "onLoadingStateChanged: Loading Initial "
                )
                LoadingState.ERROR -> Log.i("PopularQuizAdapter", "onLoadingStateChanged: Error")
                LoadingState.FINISHED -> Log.i(
                    "PopularQuizAdapter",
                    "onLoadingStateChanged: Finished "
                )
                LoadingState.LOADING_MORE -> Log.i(
                    "PopularQuizAdapter",
                    "onLoadingStateChanged: Loading More"
                )

            }
        }

    }


    private fun loadResultData() {
        firebaseFirestore.collection("quizlist").document(quizId)
            .collection("Results").document(currentUserId).get()
            .addOnCompleteListener {
                if (it.isSuccessful) {
                    val result = it.result

                    if (result != null && result.exists()) {
                        val percent : Long = result.get("percent") as Long? ?: 0L
                        detailScore.text = "$percent %"
                    }
                }
            }
    }

    override fun onClick(v: View?) {
        if(v?.id == R.id.detail_button) {
            if (quizType == "Quiz Mode" || quizType == "null") {
                val action = DetailsFragmentDirections.actionDetailsFragmentToQuizFragment()
                action.totalQuestions = totalQuestions
                action.quizid = quizId
                action.quizName = quizName
                navController.navigate(action)
            } else if (quizType == "Exam Mode") {
                //Navigate to the Exam Mode
                val action = DetailsFragmentDirections.actionDetailsFragmentToExamFragment()
                action.totalQuestions = totalQuestions
                action.quizId = quizId
                action.quizTime = quizTime
                navController.navigate(action)
            }else if (quizType == "Practice Mode"){
                val action = DetailsFragmentDirections.actionDetailsFragmentToPracticeQuizFragment()
                action.quizId = quizId
                action.quizTime = quizTime
                action.totalQuestions = totalQuestions
                navController.navigate(action)
            }
        }

    }
}