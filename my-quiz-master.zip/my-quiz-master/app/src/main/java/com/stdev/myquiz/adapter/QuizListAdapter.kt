package com.stdev.myquiz.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.stdev.myquiz.R
import com.stdev.myquiz.models.QuizListModel

//class QuizListAdapter(private val onQuizListItemClicked: OnQuizListItemClicked) :
//    RecyclerView.Adapter<QuizListAdapter.QuizViewHolder>() {
//
//    private var quizListModels: List<QuizListModel>? = null
//    //private var onQuizListItemClicked : OnQuizListItemClicked
//
//    fun setQuizListModels(quizListModels: List<QuizListModel>?) {
//        this.quizListModels = quizListModels
//    }
//
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): QuizViewHolder {
//        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.single_list_item, parent, false)
//        return QuizViewHolder(view)
//    }
//
//    override fun getItemCount(): Int {
//        return if(quizListModels == null ) 0
//        else quizListModels!!.size
//    }
//
//    override fun onBindViewHolder(holder: QuizViewHolder, position: Int) {
//        holder.listTitle.text = quizListModels!![position].name
//        val imageUrl : String? = quizListModels!![position].image
//
//        if(imageUrl != "null") {
//            holder.listImage.visibility = View.VISIBLE
//            Glide.with(holder.itemView.context)
//                .load(imageUrl)
//                .centerCrop()
//                .placeholder(R.drawable.placeholder_image)
//                .into(holder.listImage)
//        }
//
//        var listDesc = quizListModels!![position].description
//        if (listDesc?.length!! > 80) {
//            listDesc = listDesc.substring(0, 80)
//        }
//        holder.listDescription.text = "$listDesc..."
//        holder.listLevel.text = quizListModels!![position].level
//    }
//
//    inner class QuizViewHolder(itemView: View) :
//        RecyclerView.ViewHolder(itemView),
//        View.OnClickListener {
//        val listImage: ImageView = itemView.findViewById(R.id.list_image)
//        val listTitle: TextView = itemView.findViewById(R.id.list_title)
//        val listDescription: TextView = itemView.findViewById(R.id.list_description)
//        val listLevel: TextView = itemView.findViewById(R.id.list_difficulty)
//        private val listBtn: Button = itemView.findViewById(R.id.list_button)
//
//        override fun onClick(v: View) {
//            onQuizListItemClicked.onItemClicked(adapterPosition)
//        }
//
//        init {
//            listBtn.setOnClickListener(this)
//        }
//    }
//
//    interface OnQuizListItemClicked {
//        fun onItemClicked(position: Int)
//        //abstract fun PopularQuizAdapter(options: FirestorePagingOptions<QuizListModel>): PopularQuizAdapter
//    }
//}