package com.stdev.myquiz.adapter

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.firebase.ui.firestore.paging.FirestorePagingAdapter
import com.firebase.ui.firestore.paging.FirestorePagingOptions
import com.firebase.ui.firestore.paging.LoadingState
import com.stdev.myquiz.R
import com.stdev.myquiz.models.QuizListModel

//class PopularQuizAdapter(options: FirestorePagingOptions<QuizListModel>)
//    : FirestorePagingAdapter<QuizListModel, PopularQuizAdapter.PopularViewHolder>(options){
//
//
//
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PopularViewHolder {
//        val view = LayoutInflater.from(parent.context).inflate(R.layout.single_list_item,parent,false)
//        return PopularViewHolder(view)
//    }
//
//    override fun onBindViewHolder(holder: PopularViewHolder, position: Int, model: QuizListModel) {
//        holder.setPopularListData(model.name,model.level,model.image)
////        holder.quizButton.setOnClickListener {
////            val quizId = model.quiz_id
////            val action = ListFragmentDirections.actionListFragmentToDetailsFragment()
////            action.quizId = quizId!!
////
////        }
//
//
//    }
//
//    inner class PopularViewHolder (val view : View) : RecyclerView.ViewHolder(view) , View.OnClickListener {
//
//        internal fun setPopularListData(_quizName: String?,_quizLevel : String? , _quizImage : String?){
//            val quizTitle = view.findViewById<TextView>(R.id.list_title)
//            val quizLevel = view.findViewById<TextView>(R.id.list_difficulty)
//            val quizImage = view.findViewById<ImageView>(R.id.list_image)
//
//            quizTitle.text = "$_quizName"
//            quizLevel.text = "$_quizLevel"
//            if(_quizImage != "null"){
//                quizImage.visibility = View.VISIBLE
//                Glide.with(itemView.context)
//                    .load(_quizImage)
//                    .centerCrop()
//                    .placeholder(R.drawable.placeholder_image)
//                    .into(quizImage)
//            }
//
//            view.setOnClickListener(this)
//        }
//        //val quizButton : Button = view.findViewById<Button>(R.id.list_button)
//
//        override fun onClick(v: View?) {
//            onPopularItemClicked.onPopularItemClicked()
//        }
//
//
//    }
//
//    override fun onLoadingStateChanged(state: LoadingState) {
//        super.onLoadingStateChanged(state)
//        when(state){
//            LoadingState.LOADED -> Log.i("PopularQuizAdapter", "onLoadingStateChanged: Loaded $itemCount")
//            LoadingState.LOADING_INITIAL -> Log.i("PopularQuizAdapter", "onLoadingStateChanged: Loading Initial ")
//            LoadingState.ERROR -> Log.i("PopularQuizAdapter", "onLoadingStateChanged: Error")
//            LoadingState.FINISHED -> Log.i("PopularQuizAdapter", "onLoadingStateChanged: Finished ")
//            LoadingState.LOADING_MORE -> Log.i("PopularQuizAdapter", "onLoadingStateChanged: Loading More")
//
//        }
//    }
//
//}