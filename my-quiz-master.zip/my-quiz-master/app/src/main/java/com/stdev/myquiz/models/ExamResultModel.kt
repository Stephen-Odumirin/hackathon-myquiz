package com.stdev.myquiz.models

data class ExamResultModel (
    var name : String? = "null",
    var imageUrl : String? = "null",
    var email : String? = "null",
    var score : Long? = 0L,
    var totalQuestions : Long? = 0L,
    var percent : Long? = 0L
)