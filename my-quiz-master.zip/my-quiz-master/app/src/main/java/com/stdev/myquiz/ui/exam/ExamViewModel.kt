package com.stdev.myquiz.ui.exam

import androidx.lifecycle.ViewModel
import com.stdev.myquiz.models.QuestionModel

class ExamViewModel : ViewModel(){

    var initialized : Boolean = false
    lateinit var questions : List<QuestionModel>

    fun stuff(){

    }
}