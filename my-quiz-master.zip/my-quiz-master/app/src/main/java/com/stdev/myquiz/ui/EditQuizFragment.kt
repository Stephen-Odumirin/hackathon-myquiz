package com.stdev.myquiz.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.stdev.myquiz.R
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.firestore.FirebaseFirestore
import com.stdev.myquiz.models.QuestionModel

class EditQuizFragment : Fragment() , View.OnClickListener, AdapterView.OnItemSelectedListener{

    private lateinit var firebaseFirestore : FirebaseFirestore
    private lateinit var navController : NavController

    private lateinit var editQuizTitle : TextInputEditText
    private lateinit var editQuizOptionOne : TextInputEditText
    private lateinit var editQuizOptionTwo : TextInputEditText
    private lateinit var editQuizOptionThree : TextInputEditText
    private lateinit var editQuizOptionFour : TextInputEditText
    private lateinit var editQuizDescription : TextInputEditText
    private lateinit var editQuizOptionFive : TextInputEditText

    private lateinit var editOneButton : ImageView
    private lateinit var editTwoButton : ImageView
    private lateinit var editThreeButton : ImageView
    private lateinit var editFourButton : ImageView
    private lateinit var editFiveButton : ImageView

    private lateinit var editQuizButton : MaterialButton
    private lateinit var editSpinner : Spinner

    //Variables
    private var answer = ""
    private var quizId = ""
    private var questionId = ""
    private var question = ""
    private var optionOne = ""
    private var optionTwo = ""
    private var optionThree = ""
    private var optionFour = ""
    private var optionFive = ""
    private var description = ""
    private var timer = ""
    private var realTimer = 0L
    private var quizType = ""


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_edit_quiz, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        firebaseFirestore = FirebaseFirestore.getInstance()
        navController = Navigation.findNavController(view)

        quizId = EditQuizFragmentArgs.fromBundle(requireArguments()).quizId
        questionId = EditQuizFragmentArgs.fromBundle(requireArguments()).questionId
        question = EditQuizFragmentArgs.fromBundle(requireArguments()).question
        optionOne = EditQuizFragmentArgs.fromBundle(requireArguments()).optionA
        optionTwo = EditQuizFragmentArgs.fromBundle(requireArguments()).optionB
        optionThree = EditQuizFragmentArgs.fromBundle(requireArguments()).optionC
        optionFour = EditQuizFragmentArgs.fromBundle(requireArguments()).optionD
        optionFive = EditQuizFragmentArgs.fromBundle(requireArguments()).optionE
        quizType = EditQuizFragmentArgs.fromBundle(requireArguments()).quizType
        description = EditQuizFragmentArgs.fromBundle(requireArguments()).description

        editQuizTitle = view.findViewById(R.id.edit_quiz_title)
        editQuizOptionOne = view.findViewById(R.id.edit_quiz_option_one)
        editQuizOptionTwo = view.findViewById(R.id.edit_quiz_option_two)
        editQuizOptionThree = view.findViewById(R.id.edit_quiz_option_three)
        editQuizOptionFour = view.findViewById(R.id.edit_quiz_option_four)
        editQuizOptionFive = view.findViewById(R.id.edit_quiz_option_five)
        editQuizDescription = view.findViewById(R.id.edit_quiz_description)

        editOneButton = view.findViewById(R.id.edit_one_button)
        editTwoButton = view.findViewById(R.id.edit_two_button)
        editThreeButton = view.findViewById(R.id.edit_three_button)
        editFourButton = view.findViewById(R.id.edit_four_button)
        editFiveButton = view.findViewById(R.id.edit_five_button)
        editSpinner = view.findViewById(R.id.edit_quiz_timer)

        if(quizType == "Exam Mode"){
            editSpinner.visibility = View.INVISIBLE
        }else{
            editSpinner.visibility = View.VISIBLE
        }

        editQuizTitle.setText(question)
        editQuizOptionOne.setText(optionOne)
        editQuizOptionTwo.setText(optionTwo)
        editQuizOptionThree.setText(optionThree)
        editQuizOptionFour.setText(optionFour)
        editQuizOptionFive.setText(optionFive)

        editQuizDescription.setText(description)

        editOneButton.setOnClickListener(this)
        editTwoButton.setOnClickListener(this)
        editThreeButton.setOnClickListener(this)
        editFourButton.setOnClickListener(this)
        editFiveButton.setOnClickListener(this)


        editQuizButton = view.findViewById(R.id.edit_quiz_button)

        editQuizButton.setOnClickListener {
            updateQuestion()
        }

        ArrayAdapter.createFromResource(
            requireContext(),
            R.array.quiz_timer,android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            editSpinner.adapter = adapter
        }

        editSpinner.onItemSelectedListener = this

    }

    private fun updateQuestion() {
        val question = editQuizTitle.editableText.toString()
        val option1 = editQuizOptionOne.editableText.toString()
        val option2 = editQuizOptionTwo.editableText.toString()
        val option3 = editQuizOptionThree.editableText.toString()
        val option4 = editQuizOptionFour.editableText.toString()
        val option5 = editQuizOptionFive.editableText.toString()
        val description = editQuizDescription.editableText.toString()

        val hashMap = HashMap<String,Any>()
        hashMap["questionId"] = questionId
        hashMap["question"] = question
        hashMap["option_a"] = option1
        hashMap["option_b"] = option2
        hashMap["option_c"] = option3
        hashMap["option_d"] = option4
        hashMap["option_e"] = option5
        hashMap["answer"] = answer
        hashMap["description"] = description
        hashMap["timer"] = realTimer

        if (question.isNotEmpty() && option1.isNotEmpty() && option2.isNotEmpty() && answer != ""){
            firebaseFirestore.collection("quizlist").document(quizId)
                .collection("Questions").document(questionId).update(hashMap) //Todo check how to use update method for this stuffs
                .addOnSuccessListener {
                    navController.navigateUp()
                }.addOnFailureListener {
                    Toast.makeText(context, "Error => ${it.message}",Toast.LENGTH_SHORT).show()
                }
        }else{
            showToast(requireContext(),"Input All Fields")
        }

    }


    override fun onClick(v: View?) {
        when(v?.id){
            R.id.edit_one_button -> {
                answer = editQuizOptionOne.editableText.toString()
                editOneButton.setBackgroundColor(resources.getColor(R.color.green,null))
                editTwoButton.setBackgroundColor(resources.getColor(R.color.lightGrey,null))
                editThreeButton.setBackgroundColor(resources.getColor(R.color.lightGrey,null))
                editFourButton.setBackgroundColor(resources.getColor(R.color.lightGrey,null))
                editFiveButton.setBackgroundColor(resources.getColor(R.color.lightGrey,null))

            }

            R.id.edit_two_button -> {
                answer = editQuizOptionTwo.editableText.toString()
                editOneButton.setBackgroundColor(resources.getColor(R.color.lightGrey,null))
                editTwoButton.setBackgroundColor(resources.getColor(R.color.green,null))
                editThreeButton.setBackgroundColor(resources.getColor(R.color.lightGrey,null))
                editFourButton.setBackgroundColor(resources.getColor(R.color.lightGrey,null))
                editFiveButton.setBackgroundColor(resources.getColor(R.color.lightGrey,null))

            }

            R.id.edit_three_button -> {
                answer = editQuizOptionThree.editableText.toString()
                editOneButton.setBackgroundColor(resources.getColor(R.color.lightGrey,null))
                editTwoButton.setBackgroundColor(resources.getColor(R.color.lightGrey,null))
                editThreeButton.setBackgroundColor(resources.getColor(R.color.green,null))
                editFourButton.setBackgroundColor(resources.getColor(R.color.lightGrey,null))
                editFiveButton.setBackgroundColor(resources.getColor(R.color.lightGrey,null))

            }

            R.id.edit_four_button -> {
                answer = editQuizOptionFour.editableText.toString()
                editOneButton.setBackgroundColor(resources.getColor(R.color.lightGrey,null))
                editTwoButton.setBackgroundColor(resources.getColor(R.color.lightGrey,null))
                editThreeButton.setBackgroundColor(resources.getColor(R.color.lightGrey,null))
                editFourButton.setBackgroundColor(resources.getColor(R.color.green,null))
                editFiveButton.setBackgroundColor(resources.getColor(R.color.lightGrey,null))
            }

            R.id.edit_five_button -> {
                answer = editQuizOptionFive.editableText.toString()
                editOneButton.setBackgroundColor(resources.getColor(R.color.lightGrey,null))
                editTwoButton.setBackgroundColor(resources.getColor(R.color.lightGrey,null))
                editThreeButton.setBackgroundColor(resources.getColor(R.color.lightGrey,null))
                editFourButton.setBackgroundColor(resources.getColor(R.color.lightGrey,null))
                editFiveButton.setBackgroundColor(resources.getColor(R.color.green,null))
            }
        }
    }

    override fun onNothingSelected(parent: AdapterView<*>?) {

    }


    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        timer = parent?.getItemAtPosition(position) as String
        realTimer = timer.toLong()
    }

}