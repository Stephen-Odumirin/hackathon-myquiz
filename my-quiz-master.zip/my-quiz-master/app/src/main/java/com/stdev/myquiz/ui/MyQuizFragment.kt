package com.stdev.myquiz.ui

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.paging.PagedList
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.firebase.ui.firestore.paging.FirestorePagingAdapter
import com.firebase.ui.firestore.paging.FirestorePagingOptions
import com.firebase.ui.firestore.paging.LoadingState
import com.google.android.material.button.MaterialButton
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.stdev.myquiz.R
import com.stdev.myquiz.models.MyQuizModel

class MyQuizFragment : Fragment() {

    private lateinit var firebaseFirestore : FirebaseFirestore
    private lateinit var navController : NavController
    private lateinit var firebaseAuth : FirebaseAuth
    private lateinit var listView : RecyclerView
    private lateinit var fab : FloatingActionButton

    //Variables
    private var userId  = ""
    private var listAdapter : MyQuizAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_my_quiz, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        firebaseAuth = FirebaseAuth.getInstance()
        firebaseFirestore = FirebaseFirestore.getInstance()
        userId = firebaseAuth.currentUser?.uid!!
        navController = Navigation.findNavController(view)

        listView = view.findViewById(R.id.my_quiz_recycler_view)
        fab = view.findViewById(R.id.my_quiz_fab)

        fab.setOnClickListener{
            navController.navigate(R.id.action_myQuizFragment_to_newQuizFragment)
        }

        val config = PagedList.Config.Builder()
            .setInitialLoadSizeHint(5)
            .setPageSize(5)
            .build()

        val listQuery = firebaseFirestore.collection("quizlist").whereEqualTo("creator",userId)

        val listOptions = FirestorePagingOptions.Builder<MyQuizModel>()
            .setLifecycleOwner(this)
            .setQuery(listQuery,config,MyQuizModel::class.java)
            .build()

        listView.layoutManager = LinearLayoutManager(context)
        listAdapter = MyQuizAdapter(listOptions)
        listView.adapter = listAdapter

    }

    private inner class MyQuizAdapter(options: FirestorePagingOptions<MyQuizModel>) :
        FirestorePagingAdapter<MyQuizModel, MyQuizAdapter.MyQuizViewHolder>(options) {


        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyQuizViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.single_my_quiz_list, parent, false)
            return MyQuizViewHolder(view)
        }

        override fun onBindViewHolder(holder: MyQuizViewHolder, position: Int, model: MyQuizModel) {
            holder.setListData(model.name,model.description,model.image,model.level,model.questions,model.quizType)
            holder.button.setOnClickListener {
                val quizId = model.quiz_id
                val quizType = model.quizType
                val action = MyQuizFragmentDirections.actionMyQuizFragmentToAddQuizListFragment()
                action.quizId = quizId ?: "null"
                action.quizType = quizType ?: "null"
                Toast.makeText(context, "You clicked on Quiz Id -> ${model.quiz_id} , Quiz Name -> ${model.name}\n Quiz Type -> ${model.quizType}",Toast.LENGTH_SHORT).show()
                navController.navigate(action)
            }
            holder.examButton.setOnClickListener{
                val quizId = model.quiz_id
                val action = MyQuizFragmentDirections.actionMyQuizFragmentToExamFragmentResults()
                action.quizId = quizId ?: "null"
                navController.navigate(action)
            }

        }

        inner class MyQuizViewHolder(val view: View) : RecyclerView.ViewHolder(view) {

            internal fun setListData(_quizName: String?,_quizDescription : String? , _quizImage : String?, _quizLevel: String?, _quizTotalQuestions : Long?, _quizType : String?) {
                val quizTitle = view.findViewById<TextView>(R.id.my_quiz_title)
                val quizLevel = view.findViewById<TextView>(R.id.my_quiz_level)
                val quizImage = view.findViewById<ImageView>(R.id.my_quiz_image)
                val quizDescription = view.findViewById<TextView>(R.id.my_quiz_description)
                val quizType = view.findViewById<TextView>(R.id.my_quiz_type)
                val quizTotalQuestions = view.findViewById<TextView>(R.id.my_quiz_total_questions)

                quizTitle.text = "$_quizName"
                quizLevel.text = "$_quizLevel"
                quizDescription.text = "$_quizDescription"
                quizTotalQuestions.text = "$_quizTotalQuestions"
                quizType.text = "$_quizType"
                if (_quizImage != "null") {
                    quizImage.visibility = View.VISIBLE
                    Glide.with(itemView.context)
                        .load(_quizImage)
                        .centerCrop()
                        .placeholder(R.drawable.placeholder_image)
                        .into(quizImage)
                }
                if(_quizType == "Exam Mode"){
                    examButton.visibility = View.VISIBLE
                }

            }

            val button : MaterialButton = view.findViewById(R.id.my_quiz_edit_button)
            val examButton : MaterialButton = view.findViewById(R.id.my_quiz_exam_button)
        }

        override fun onLoadingStateChanged(state: LoadingState) {
            super.onLoadingStateChanged(state)
            when (state) {
                LoadingState.LOADED -> Log.i(
                    "PopularQuizAdapter",
                    "onLoadingStateChanged: Loaded $itemCount"
                )
                LoadingState.LOADING_INITIAL -> Log.i(
                    "PopularQuizAdapter",
                    "onLoadingStateChanged: Loading Initial "
                )
                LoadingState.ERROR -> Log.i("PopularQuizAdapter", "onLoadingStateChanged: Error")
                LoadingState.FINISHED -> Log.i(
                    "PopularQuizAdapter",
                    "onLoadingStateChanged: Finished "
                )
                LoadingState.LOADING_MORE -> Log.i(
                    "PopularQuizAdapter",
                    "onLoadingStateChanged: Loading More"
                )

            }
        }

    }


}