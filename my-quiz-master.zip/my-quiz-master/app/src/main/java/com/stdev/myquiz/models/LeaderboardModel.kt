package com.stdev.myquiz.models

data class LeaderboardModel (
    var name : String? = "null",
    var imageUrl : String? = "null",
    var percent : Long? = 0L
)