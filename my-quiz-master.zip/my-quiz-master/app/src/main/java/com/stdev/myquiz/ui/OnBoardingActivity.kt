package com.stdev.myquiz.ui

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.fragment.app.Fragment
import com.github.appintro.AppIntro
import com.github.appintro.AppIntroFragment
import com.github.appintro.AppIntroPageTransformerType
import com.stdev.myquiz.R

class OnBoardingActivity : AppIntro() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_onboarding)
        setTransformer(AppIntroPageTransformerType.Fade)
        isColorTransitionsEnabled = true
        isIndicatorEnabled = true
        setIndicatorColor(
            selectedIndicatorColor = resources.getColor(R.color.colorPrimary),
            unselectedIndicatorColor = resources.getColor(R.color.colorLightText)
        )
        showStatusBar(true)
        setNavBarColor(Color.TRANSPARENT)

        addSlide(
            AppIntroFragment.newInstance(
                title = "Welcome To My Quiz App",
                description = "Lemme show you some cool stuffs about this App"
            )
        )

        addSlide(
            AppIntroFragment.newInstance(
                title = "You can create questions within 60 Seconds",
                description = "More cool Stuffs on the way"
            )
        )

        addSlide(
            AppIntroFragment.newInstance(
                title = "You can share questions with 60 Friends",
                description = "More cool Stuffs on the way"
            )
        )

    }

    override fun onSkipPressed(currentFragment: Fragment?) {
        super.onSkipPressed(currentFragment)
        val intent = Intent(this, SignUpActivity::class.java)
        startActivity(intent)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK and Intent.FLAG_ACTIVITY_CLEAR_TOP
        finish()
    }

    override fun onDonePressed(currentFragment: Fragment?) {
        super.onDonePressed(currentFragment)
        val intent = Intent(this, SignUpActivity::class.java)
        startActivity(intent)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK and Intent.FLAG_ACTIVITY_CLEAR_TOP
        finish()
    }
}