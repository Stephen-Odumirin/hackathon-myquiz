package com.stdev.myquiz.ui.exam

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.paging.PagedList
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.firebase.ui.firestore.paging.FirestorePagingAdapter
import com.firebase.ui.firestore.paging.FirestorePagingOptions
import com.firebase.ui.firestore.paging.LoadingState
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.stdev.myquiz.R
import com.stdev.myquiz.models.ExamResultModel
import com.stdev.myquiz.models.LeaderboardModel

class ExamFragmentResults : Fragment() {

    private lateinit var firebaseFirestore : FirebaseFirestore
    private lateinit var firebaseAuth : FirebaseAuth
    private lateinit var listView : RecyclerView
    private var adapter : ExamResultsAdapter? = null

    private var quizId = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_exam_result,container,false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        firebaseFirestore = FirebaseFirestore.getInstance()
        firebaseAuth = FirebaseAuth.getInstance()

        quizId = ExamFragmentResultsArgs.fromBundle(requireArguments()).quizId

        listView = view.findViewById(R.id.exam_result_list)

        val config = PagedList.Config.Builder()
            .setInitialLoadSizeHint(10)
            .setPageSize(5)
            .build()

        val listQuery = firebaseFirestore.collection("quizlist").document(quizId)
            .collection("Results")
            .orderBy("percent", Query.Direction.DESCENDING)

        val listOptions = FirestorePagingOptions.Builder<ExamResultModel>()
            .setLifecycleOwner(this)
            .setQuery(listQuery,config,ExamResultModel::class.java)
            .build()

        listView.layoutManager = LinearLayoutManager(context)
        adapter = ExamResultsAdapter(listOptions)
        listView.adapter = adapter
    }

    private inner class ExamResultsAdapter(options: FirestorePagingOptions<ExamResultModel>) :
        FirestorePagingAdapter<ExamResultModel, ExamResultsAdapter.ExamResultsHolder>(options) {


        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExamResultsHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.single_exam_result, parent, false)
            return ExamResultsHolder(view)
        }

        override fun onBindViewHolder(holder: ExamResultsHolder, position: Int, model:ExamResultModel) {
            holder.setListData(model.name,model.score,model.percent,model.email,model.imageUrl,model.totalQuestions)
        }

        inner class ExamResultsHolder(val view: View) : RecyclerView.ViewHolder(view) {

            internal fun setListData(_userName: String?, _quizScore: Long?,_quizPercent : Long? ,_userEmail: String? ,_userImage: String?,_totalQuestions : Long?) {
                val userName = view.findViewById<TextView>(R.id.exam_result_name)
                val quizScore = view.findViewById<TextView>(R.id.exam_result_score)
                val userImage = view.findViewById<ImageView>(R.id.exam_result_image)
                val quizPercent = view.findViewById<TextView>(R.id.exam_result_percent)
                val userEmail = view.findViewById<TextView>(R.id.exam_result_email)

                userName.text = "$_userName"
                quizScore.text = "$_quizScore / $_totalQuestions"
                quizPercent.text = "$_quizPercent %"
                userEmail.text = "$_userEmail"

                if (_userImage != "null") {
                    userImage.visibility = View.VISIBLE
                    Glide.with(view)
                        .load(_userImage)
                        .centerCrop()
                        .placeholder(R.drawable.placeholder_image)
                        .into(userImage)
                }
            }
        }

        override fun onLoadingStateChanged(state: LoadingState) {
            super.onLoadingStateChanged(state)
            when (state) {
                LoadingState.LOADED -> Log.i(
                    "PopularQuizAdapter",
                    "onLoadingStateChanged: Loaded $itemCount"
                )
                LoadingState.LOADING_INITIAL -> Log.i(
                    "PopularQuizAdapter",
                    "onLoadingStateChanged: Loading Initial "
                )
                LoadingState.ERROR -> Log.i("PopularQuizAdapter", "onLoadingStateChanged: Error")
                LoadingState.FINISHED -> Log.i(
                    "PopularQuizAdapter",
                    "onLoadingStateChanged: Finished "
                )
                LoadingState.LOADING_MORE -> Log.i(
                    "PopularQuizAdapter",
                    "onLoadingStateChanged: Loading More"
                )

            }
        }

    }




}