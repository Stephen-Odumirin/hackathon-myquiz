package com.stdev.myquiz.ui

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.*
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.paging.PagedList
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.bumptech.glide.Glide
import com.firebase.ui.firestore.paging.FirestorePagingAdapter
import com.firebase.ui.firestore.paging.FirestorePagingOptions
import com.firebase.ui.firestore.paging.LoadingState
import com.google.android.material.button.MaterialButton
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.Query
import com.stdev.myquiz.viewmodel.QuizListViewModel
import com.stdev.myquiz.R
import com.stdev.myquiz.models.QuizListModel

class ListFragment : Fragment() {

    private lateinit var listView: RecyclerView
    private lateinit var quizListViewModel: QuizListViewModel
    private lateinit var listAdapter: ListQuizAdapter
    private lateinit var progressBar: ProgressBar
    private lateinit var fadeInAnim: Animation
    private lateinit var fadeOutAnim: Animation
    private lateinit var navController: NavController
    
    private lateinit var newlistView: RecyclerView
    private lateinit var popularRecyclerView: RecyclerView

    private lateinit var firebaseFirestore: FirebaseFirestore

    private lateinit var searchEditText : EditText
    private lateinit var searchButton : ImageView

    private var adapter: NewestQuizAdapter? = null
    private var popularAdapter: PopularQuizAdapter? = null

    private var quizId = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_list, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        firebaseFirestore = FirebaseFirestore.getInstance()

        //Offline Capapbilities


        progressBar = view.findViewById(R.id.list_progress)
        listView = view.findViewById(R.id.list_view)
        fadeInAnim = AnimationUtils.loadAnimation(context, R.anim.fade_in)
        fadeOutAnim = AnimationUtils.loadAnimation(context, R.anim.fade_out)
        navController = Navigation.findNavController(view)

        newlistView = view.findViewById(R.id.newestRecyclerView)
        popularRecyclerView = view.findViewById(R.id.popularRecyclerView)

        searchEditText = view.findViewById(R.id.list_enter_quiz_id_text)
        searchButton = view.findViewById(R.id.list_search_quiz_button)

        searchButton.setOnClickListener {
            val searchText = searchEditText.editableText.toString()
            searchForQuiz(searchText)
        }

        val config = PagedList.Config.Builder()
            .setInitialLoadSizeHint(5)
            .setPageSize(5)
            .build()

        //List Adapter
        val listQuery: Query =
            firebaseFirestore.collection("quizlist").whereEqualTo("visibility", "public").orderBy("avgRating", Query.Direction.DESCENDING)
        val listOptions = FirestorePagingOptions.Builder<QuizListModel>()
            .setLifecycleOwner(this)
            .setQuery(listQuery, config, QuizListModel::class.java)
            .build()

        listView.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        listAdapter = ListQuizAdapter(listOptions)//QuizListAdapter(this)
        listView.adapter = listAdapter

        //Newest Adapter
        val query: Query =
            firebaseFirestore.collection("quizlist").whereEqualTo("visibility", "public").orderBy("timestamp",Query.Direction.DESCENDING)
        val newestOptions = FirestorePagingOptions.Builder<QuizListModel>()
            .setLifecycleOwner(this)
            .setQuery(query, config, QuizListModel::class.java)
            .build()
        newlistView.layoutManager =
            LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        adapter = NewestQuizAdapter(newestOptions)
        newlistView.adapter = adapter

        //Popular Adapter
        val popularQuery: Query =
            firebaseFirestore.collection("quizlist").whereEqualTo("visibility", "public").orderBy("timesTaken", Query.Direction.DESCENDING)
        //.orderBy("timestamp",Query.Direction.ASCENDING)
        val popularOptions = FirestorePagingOptions.Builder<QuizListModel>()
            .setQuery(popularQuery, config, QuizListModel::class.java)
            .setLifecycleOwner(this)
            .build()
        popularRecyclerView.layoutManager =
            LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        popularAdapter = PopularQuizAdapter(popularOptions)
        popularRecyclerView.adapter = popularAdapter

    }

    private fun searchForQuiz(searchText : String){
        if(searchText.isEmpty()){
            showToast(requireContext(),"Enter Quiz Id")
        } else{
            val docRef = firebaseFirestore.collection("quizlist").document(searchText)
            docRef.get().addOnSuccessListener {
                if(it.data != null && it.exists()){
                    quizId = it.id
                    val action = ListFragmentDirections.actionListFragmentToDetailsFragment()
                    action.quizId = quizId
                    navController.navigate(action)
                }else{
                    showToast(requireContext(),"Incorrect Quiz Id...")
                }
            }.addOnFailureListener{
                showToast(requireContext(),"Error -> ${it.message}")
            }
        }
    }

    private inner class ListQuizAdapter(options: FirestorePagingOptions<QuizListModel>) :
        FirestorePagingAdapter<QuizListModel, ListQuizAdapter.ListViewHolder>(options) {


        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.single_list_item, parent, false)
            return ListViewHolder(view)
        }

        override fun onBindViewHolder(holder: ListViewHolder, position: Int, model: QuizListModel) {
            holder.setListData(model.name, model.level, model.image,model.description,model.quizType)
            holder.quizButton.setOnClickListener {
                val quizId = model.quiz_id
                val action = ListFragmentDirections.actionListFragmentToDetailsFragment()
                action.quizId = quizId
                Log.i("ListFragment", "You Clicked on $position : QuizId : $quizId")
                navController.navigate(action)

            }


        }

        inner class ListViewHolder(val view: View) : RecyclerView.ViewHolder(view) {

            internal fun setListData(_quizName: String?, _quizLevel: String?, _quizImage: String?, _quizDescription : String? , _quizType : String?) {
                val quizTitle = view.findViewById<TextView>(R.id.list_title)
                val quizLevel = view.findViewById<TextView>(R.id.list_difficulty)
                val quizImage = view.findViewById<ImageView>(R.id.list_image)
                val quizDescription = view.findViewById<TextView>(R.id.list_description)
                val quizType = view.findViewById<TextView>(R.id.list_type)

                quizTitle.text = "$_quizName"
                quizLevel.text = "$_quizLevel"
                if (_quizImage != "null") {
                    context?.let {
                        quizImage.visibility = View.VISIBLE
                        Glide.with(it)
                            .load(_quizImage)
                            .centerCrop()
                            .placeholder(R.drawable.placeholder_image)
                            .into(quizImage)
                    }

                }
                quizDescription.text = "$_quizDescription"
                quizType.text = "$_quizType"
            }

            val quizButton: MaterialButton = view.findViewById(R.id.list_button)


        }

        override fun onLoadingStateChanged(state: LoadingState) {
            super.onLoadingStateChanged(state)
            when (state) {
                LoadingState.LOADED -> Log.i(
                    "PopularQuizAdapter",
                    "onLoadingStateChanged: Loaded $itemCount"
                )
                LoadingState.LOADING_INITIAL -> Log.i(
                    "PopularQuizAdapter",
                    "onLoadingStateChanged: Loading Initial "
                )
                LoadingState.ERROR -> Log.i("PopularQuizAdapter", "onLoadingStateChanged: Error")
                LoadingState.FINISHED -> Log.i(
                    "PopularQuizAdapter",
                    "onLoadingStateChanged: Finished "
                )
                LoadingState.LOADING_MORE -> Log.i(
                    "PopularQuizAdapter",
                    "onLoadingStateChanged: Loading More"
                )

            }
        }

    }

    private inner class PopularQuizAdapter(options: FirestorePagingOptions<QuizListModel>) :
        FirestorePagingAdapter<QuizListModel, PopularQuizAdapter.PopularViewHolder>(options) {


        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PopularViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.single_list_item, parent, false)
            return PopularViewHolder(view)
        }

        override fun onBindViewHolder(
            holder: PopularViewHolder,
            position: Int,
            model: QuizListModel
        ) {
            holder.setPopularListData(model.name, model.level, model.image,model.description,model.quizType)
            holder.quizButton.setOnClickListener {
                val quizId = model.quiz_id
                val action = ListFragmentDirections.actionListFragmentToDetailsFragment()
                action.quizId = quizId
                Log.i("ListFragment", "You Clicked on $position : QuizId : $quizId")
                navController.navigate(action)

            }


        }

        inner class PopularViewHolder(val view: View) : RecyclerView.ViewHolder(view) {

            internal fun setPopularListData(
                _quizName: String?,
                _quizLevel: String?,
                _quizImage: String?,
                _quizDescription: String?,
                _quizType: String?
            ) {
                val quizTitle = view.findViewById<TextView>(R.id.list_title)
                val quizLevel = view.findViewById<TextView>(R.id.list_difficulty)
                val quizImage = view.findViewById<ImageView>(R.id.list_image)
                val quizDescription = view.findViewById<TextView>(R.id.list_description)
                val quizType = view.findViewById<TextView>(R.id.list_type)

                quizTitle.text = "$_quizName"
                quizLevel.text = "$_quizLevel"
                if (_quizImage != "null") {
                    context?.let {
                        quizImage.visibility = View.VISIBLE
                        Glide.with(it)
                            .load(_quizImage)
                            .centerCrop()
                            .placeholder(R.drawable.placeholder_image)
                            .into(quizImage)
                    }
                }
                quizDescription.text = "$_quizDescription"
                quizType.text = "$_quizType"
            }

            val quizButton: MaterialButton = view.findViewById(R.id.list_button)


        }

        override fun onLoadingStateChanged(state: LoadingState) {
            super.onLoadingStateChanged(state)
            when (state) {
                LoadingState.LOADED -> Log.i(
                    "PopularQuizAdapter",
                    "onLoadingStateChanged: Loaded $itemCount"
                )
                LoadingState.LOADING_INITIAL -> Log.i(
                    "PopularQuizAdapter",
                    "onLoadingStateChanged: Loading Initial "
                )
                LoadingState.ERROR -> Log.i("PopularQuizAdapter", "onLoadingStateChanged: Error")
                LoadingState.FINISHED -> Log.i(
                    "PopularQuizAdapter",
                    "onLoadingStateChanged: Finished "
                )
                LoadingState.LOADING_MORE -> Log.i(
                    "PopularQuizAdapter",
                    "onLoadingStateChanged: Loading More"
                )

            }
        }

    }

    private inner class NewestQuizAdapter(options: FirestorePagingOptions<QuizListModel>) :
        FirestorePagingAdapter<QuizListModel, NewestQuizAdapter.NewestListViewHolder>(options) {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NewestListViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.single_list_item, parent, false)
            return NewestListViewHolder(view)
        }

        override fun onBindViewHolder(
            holder: NewestListViewHolder,
            position: Int,
            model: QuizListModel
        ) {
            holder.setNewestListData(model.name, model.level, model.image,model.description,model.quizType)
            Log.i("ProfileFragment", "onBindViewHolder: Data ${model.name} ")
            holder.quizButton.setOnClickListener {
                val quizId = model.quiz_id
                val action = ListFragmentDirections.actionListFragmentToDetailsFragment()
                action.quizId = quizId
                navController.navigate(action)
            }
        }


        inner class NewestListViewHolder internal constructor(private val view: View) :
            RecyclerView.ViewHolder(view) {
            internal fun setNewestListData(
                _quizName: String?,
                _quizLevel: String,
                _quizImage: String,
                _quizDescription: String?,
                _quizType: String?
            ) {
                val quizTitle = view.findViewById<TextView>(R.id.list_title)
                val quizLevel = view.findViewById<TextView>(R.id.list_difficulty)
                val quizImage = view.findViewById<ImageView>(R.id.list_image)
                val quizDescription = view.findViewById<TextView>(R.id.list_description)
                val quizType = view.findViewById<TextView>(R.id.list_type)

                quizTitle.text = "$_quizName" //?: "null"
                quizLevel.text = "$_quizLevel" //?: "null"
                if (_quizImage != "null") {
                    context?.let {
                        quizImage.visibility = View.VISIBLE
                        Glide.with(it).load(_quizImage).into(quizImage)
                    }
                }
                quizDescription.text = "$_quizDescription"
                quizType.text = "$_quizType"
            }

            val quizButton: MaterialButton = view.findViewById(R.id.list_button)
        }

        override fun onLoadingStateChanged(state: LoadingState) {
            super.onLoadingStateChanged(state)
            when (state) {
                LoadingState.LOADED -> Log.i(
                    "NewestQuizAdapter",
                    "onLoadingStateChanged: Loaded $itemCount"
                )
                LoadingState.LOADING_INITIAL -> Log.i(
                    "NewestQuizAdapter",
                    "onLoadingStateChanged: Loading Initial "
                )
                LoadingState.ERROR -> Log.i("NewestQuizAdapter", "onLoadingStateChanged: Error")
                LoadingState.FINISHED -> Log.i(
                    "NewestQuizAdapter",
                    "onLoadingStateChanged: Finished "
                )
                LoadingState.LOADING_MORE -> Log.i(
                    "NewestQuizAdapter",
                    "onLoadingStateChanged: Loading More"
                )

            }
        }
    }
}
