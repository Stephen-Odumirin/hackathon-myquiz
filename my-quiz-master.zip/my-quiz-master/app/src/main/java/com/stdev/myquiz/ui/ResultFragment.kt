package com.stdev.myquiz.ui

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.google.android.material.button.MaterialButton
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.stdev.myquiz.R
import com.stdev.myquiz.ui.dialogs.RatingDialog

class ResultFragment : Fragment() {

    private lateinit var firebaseFirestore: FirebaseFirestore
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var navController : NavController

    private lateinit var resultTitle: TextView
    private lateinit var resultProgress: ProgressBar
    private lateinit var resultPercent: TextView
    private lateinit var resultCorrect: TextView
    private lateinit var resultWrong: TextView
    private lateinit var resultMissed: TextView
    private lateinit var rateButton : MaterialButton

    private lateinit var resultHomeButton: MaterialButton
    private lateinit var leaderboardButton : MaterialButton

    private var currentUserId = ""
    private var quizName = ""
    private var quizId = ""
    private var rating = 0
    private var ratingComment = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_result, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        firebaseAuth = FirebaseAuth.getInstance()
        navController = Navigation.findNavController(view)

        currentUserId = firebaseAuth.currentUser?.uid!!
        firebaseFirestore = FirebaseFirestore.getInstance()
        quizId = ResultFragmentArgs.fromBundle(requireArguments()).quizId

        //initialize Ui Elements
        resultCorrect = view.findViewById(R.id.results_correct_text)
        resultWrong = view.findViewById(R.id.results_wrong_text)
        resultMissed = view.findViewById(R.id.results_missed_text)
        resultHomeButton = view.findViewById(R.id.results_home_button)
        resultPercent = view.findViewById(R.id.results_percent)
        resultProgress = view.findViewById(R.id.results_progress)
        leaderboardButton = view.findViewById(R.id.results_view_leaderboard)
        rateButton = view.findViewById(R.id.results_rate_quiz)

        rateButton.setOnClickListener {
//            val action = ResultFragmentDirections.actionResultFragmentToMyDialogFragment()
//            action.quizId = quizId
//            navController.navigate(action)
            val dialog = RatingDialog(quizId)
            dialog.show(childFragmentManager,"MyDialogFragment")
        }

        resultHomeButton.setOnClickListener {
            navController.navigate(R.id.action_resultFragment_to_listFragment)
        }

        leaderboardButton.setOnClickListener {
            val action = ResultFragmentDirections.actionResultFragmentToLeaderBoardFragment()
            action.quizId = quizId
            Toast.makeText(context, "Leaderboard Button Clicked", Toast.LENGTH_SHORT).show()
            navController.navigate(action)
        }

        updateTotal()

        //Get Results
        getResults()
    }

    private fun getResults() {
        firebaseFirestore.collection("quizlist").document(quizId)
            .collection("Results").document(currentUserId).get()
            .addOnCompleteListener {
                if (it.isSuccessful) {
                    val result = it.result
                    val correct: Long = result?.get("correct") as Long? ?: 0L
                    val wrong: Long = result.get("wrong") as Long? ?: 0L
                    val missed: Long = result.get("unanswered") as Long? ?: 0L
                    val percent: Long = result.get("percent") as Long? ?: 0L

                    resultCorrect.text = correct.toString()
                    resultWrong.text = wrong.toString()
                    resultMissed.text = missed.toString()

                    //Calculate Progress
                    //val total = correct + wrong + missed
                    //val percent = (correct * 100) / total
                    resultProgress.progress = percent.toInt()
                    resultPercent.text = "$percent % "
                    //Log.i("ResultFragment", "Result Log ${total.toString()} ")
                    Log.i("ResultFragment", "Result log Percent ${percent}")

                    //
                }
            }
    }

    private fun updateTotal() {
        firebaseFirestore.collection("quizlist").document(quizId).collection("Results").get()
            .addOnCompleteListener {
                if (it.isSuccessful){
                    val timesTaken = it.result.size()
                    val hashMap = HashMap<String, Any>()
                    hashMap["timesTaken"] = timesTaken
                    firebaseFirestore.collection("quizlist").document(quizId).update(hashMap).addOnCompleteListener {task->
                        if(task.isSuccessful){
                            showToast(requireContext(), "Updated the Total Times...")
                        }
                    }
                }
            }
    }

}
