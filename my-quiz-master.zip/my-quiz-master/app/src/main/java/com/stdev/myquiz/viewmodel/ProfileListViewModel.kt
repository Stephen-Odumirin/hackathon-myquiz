package com.stdev.myquiz.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.stdev.myquiz.models.ProfileListModel

class ProfileListViewModel : ViewModel() {
    private val profileListModelData = MutableLiveData<List<ProfileListViewModel>>()
    private val firebaseFirestore = FirebaseFirestore.getInstance()
    private val firebaseAuth = FirebaseAuth.getInstance()

    private val userId = firebaseAuth.currentUser?.uid

    private val profileReference =
        firebaseFirestore.collection("users").document(userId!!).collection("Results")

//    fun getProfileData() : LiveData<List<ProfileListModel>>{
//        profileReference.get().addOnCompleteListener {
//            if(it.isSuccessful){
//                it.result?.toObjects(ProfileListViewModel::class.java)
//                return profileListModelData
//            }else{
//                //Error handling
//            }
//        }
//
//    }


//    init {
//        getProfileData()
//    }

}
/*
class QuizListViewModel : ViewModel(), OnFirestoreTaskComplete {
    private val quizListModelData = MutableLiveData<List<QuizListModel>>()
    private val firebaseRepository = FirebaseRepository(this)

    init {
        firebaseRepository.getQuizData()
    }

    fun getQuizListModelData(): LiveData<List<QuizListModel>> {
        firebaseRepository.getQuizData()//Todo changed this shii
        return quizListModelData
    }

    override fun quizListDataAdded(quizList: List<QuizListModel>) {
        quizListModelData.value = quizList
    }

    override fun onError(e: Exception) {
        Log.d("QuizListViewModel", "onError: ${e.message}")
    }
}
*/

/*

class FirebaseRepository (private val onFirestoreTaskComplete: OnFirestoreTaskComplete){

    private val firebaseFirestore: FirebaseFirestore = FirebaseFirestore.getInstance()
    private val quizReference = firebaseFirestore.collection("quizlist").whereEqualTo("visibility","public")

    private val profileReference = firebaseFirestore.collection("users")


    fun getQuizData() {
        quizReference.get().addOnCompleteListener {
            if (it.isSuccessful) {
                onFirestoreTaskComplete.quizListDataAdded(it.result?.toObjects(QuizListModel::class.java)!!)
            } else {
                onFirestoreTaskComplete.onError(it.exception!!)
            }
        }
    }

    interface OnFirestoreTaskComplete{
        fun quizListDataAdded(quizList: List<QuizListModel>)
        fun onError(e: Exception)
    }



 */
