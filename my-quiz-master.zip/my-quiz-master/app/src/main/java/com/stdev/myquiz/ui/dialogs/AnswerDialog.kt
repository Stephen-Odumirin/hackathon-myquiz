package com.stdev.myquiz.ui.dialogs

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import com.bumptech.glide.Glide
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.dialog.MaterialDialogs
import com.stdev.myquiz.R

class AnswerDialog(private var image : ImageView, private var title : String , private var description : String) : DialogFragment() {


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.dialog_answer,container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val imageView : ImageView = view.findViewById(R.id.dialog_answer_image)
        val title : TextView = view.findViewById(R.id.dialog_answer_title)
        val description : TextView = view.findViewById(R.id.dialog_answer_explanation)

        Glide.with(view)
            .load(image)
            .into(imageView)
        title.text = "$title"
        description.text = "$description"

    }

}