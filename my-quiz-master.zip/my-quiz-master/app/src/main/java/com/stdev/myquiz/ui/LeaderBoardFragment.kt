package com.stdev.myquiz.ui

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.paging.PagedList
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.firebase.ui.firestore.paging.FirestorePagingAdapter
import com.firebase.ui.firestore.paging.FirestorePagingOptions
import com.firebase.ui.firestore.paging.LoadingState
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.stdev.myquiz.R
import com.stdev.myquiz.models.LeaderboardModel

class LeaderBoardFragment : Fragment() {

    private lateinit var firebaseFirestore: FirebaseFirestore
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var listView: RecyclerView
    private var adapter: LeaderboardAdapter? = null

    //Variables
    private var quizId = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_leader_board, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        firebaseFirestore = FirebaseFirestore.getInstance()
        firebaseAuth = FirebaseAuth.getInstance()

        quizId = LeaderBoardFragmentArgs.fromBundle(
            requireArguments()
        ).quizId

        listView = view.findViewById(R.id.leaderboard_recycler_view)

        val config = PagedList.Config.Builder()
            .setInitialLoadSizeHint(10)
            .setPageSize(5)
            .build()

        val listQuery : Query = firebaseFirestore.collection("quizlist").document(quizId)
            .collection("Results")
            .orderBy("percent", Query.Direction.DESCENDING)

        val listOptions = FirestorePagingOptions.Builder<LeaderboardModel>()
            .setLifecycleOwner(this)
            .setQuery(listQuery, config, LeaderboardModel::class.java)
            .build()

        listView.layoutManager = LinearLayoutManager(context)
        adapter = LeaderboardAdapter(listOptions)
        listView.adapter = adapter

    }

    private inner class LeaderboardAdapter(options: FirestorePagingOptions<LeaderboardModel>) :
        FirestorePagingAdapter<LeaderboardModel, LeaderboardAdapter.LeaderboardHolder>(options) {


        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LeaderboardHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.single_leaderboard_list, parent, false)
            return LeaderboardHolder(view)
        }

        override fun onBindViewHolder(holder: LeaderboardHolder, position: Int, model: LeaderboardModel) {
            holder.setListData(model.name,model.percent,model.imageUrl)
        }

        inner class LeaderboardHolder(val view: View) : RecyclerView.ViewHolder(view) {

            internal fun setListData(_userName: String?, _quizPercent: Long?, _userImage: String?) {
                val userName = view.findViewById<TextView>(R.id.leaderboard_name)
                val quizScore = view.findViewById<TextView>(R.id.leaderboard_score)
                val userImage = view.findViewById<ImageView>(R.id.leaderboard_image)

                userName.text = "$_userName"
                quizScore.text = "$_quizPercent %"
                if (_userImage != "null") {
                    userImage.visibility = View.VISIBLE
                    Glide.with(view)
                        .load(_userImage)
                        .centerCrop()
                        .placeholder(R.drawable.placeholder_image)
                        .into(userImage)
                }
            }
        }

        override fun onLoadingStateChanged(state: LoadingState) {
            super.onLoadingStateChanged(state)
            when (state) {
                LoadingState.LOADED -> Log.i(
                    "PopularQuizAdapter",
                    "onLoadingStateChanged: Loaded $itemCount"
                )
                LoadingState.LOADING_INITIAL -> Log.i(
                    "PopularQuizAdapter",
                    "onLoadingStateChanged: Loading Initial "
                )
                LoadingState.ERROR -> Log.i("PopularQuizAdapter", "onLoadingStateChanged: Error")
                LoadingState.FINISHED -> Log.i(
                    "PopularQuizAdapter",
                    "onLoadingStateChanged: Finished "
                )
                LoadingState.LOADING_MORE -> Log.i(
                    "PopularQuizAdapter",
                    "onLoadingStateChanged: Loading More"
                )

            }
        }

    }

}