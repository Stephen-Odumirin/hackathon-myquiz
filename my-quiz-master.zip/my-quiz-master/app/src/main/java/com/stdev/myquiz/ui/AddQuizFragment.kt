package com.stdev.myquiz.ui

import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.google.firebase.firestore.FirebaseFirestore
import com.stdev.myquiz.R
import com.stdev.myquiz.models.QuestionModel

class AddQuizFragment : Fragment(), View.OnClickListener, AdapterView.OnItemSelectedListener {

    private lateinit var firebaseFirestore: FirebaseFirestore
    private lateinit var navController: NavController
    private lateinit var listView : RecyclerView

    //Views
    private lateinit var questionText: TextInputEditText
    private lateinit var optionOne: TextInputEditText
    private lateinit var optionTwo: TextInputEditText
    private lateinit var optionThree: TextInputEditText
    private lateinit var optionFour: TextInputEditText
    private lateinit var optionFive: TextInputEditText

    private lateinit var descriptionText : TextInputEditText
    private lateinit var optionOneLayout : TextInputLayout
    private lateinit var optionTwoLayout : TextInputLayout
    private lateinit var optionThreeLayout : TextInputLayout
    private lateinit var optionFourLayout : TextInputLayout
    private lateinit var optionFiveLayout : TextInputLayout

    private lateinit var button: MaterialButton
    private lateinit var feedback: TextView
    private lateinit var quizIdText: TextView
    private lateinit var buttonOne: ImageView
    private lateinit var buttonTwo: ImageView
    private lateinit var buttonThree: ImageView
    private lateinit var buttonFour: ImageView
    private lateinit var buttonFive : ImageView

    private lateinit var addOptionButton : MaterialButton
    private lateinit var removeOptionButton :MaterialButton

    private lateinit var timerSpinner : Spinner

    //
    private var questionId = ""
    private var quizId = ""
    private var quizType = ""
    private var selected = false
    private var answer = ""
    private var timer = ""
    private var realTimer = 0L
    private var currentOption = 2
    private var lastOption = 6


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_add_quiz, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        firebaseFirestore = FirebaseFirestore.getInstance()
        navController = Navigation.findNavController(view)

        questionId = AddQuizFragmentArgs.fromBundle(requireArguments()).questionId
        quizId = AddQuizFragmentArgs.fromBundle(requireArguments()).quizId
        quizType = AddQuizFragmentArgs.fromBundle(requireArguments()).quizType

        questionText = view.findViewById(R.id.add_quiz_title)

        optionOne = view.findViewById(R.id.add_quiz_option_one)
        optionTwo = view.findViewById(R.id.add_quiz_option_two)
        optionThree = view.findViewById(R.id.add_quiz_option_three)
        optionFour = view.findViewById(R.id.add_quiz_option_four)
        optionFive = view.findViewById(R.id.add_quiz_option_five)

        optionThreeLayout = view.findViewById(R.id.add_quiz_layout_three)
        optionFourLayout = view.findViewById(R.id.add_quiz_layout_four)
        optionFiveLayout = view.findViewById(R.id.add_quiz_layout_five)

        descriptionText = view.findViewById(R.id.add_quiz_description)

        button = view.findViewById(R.id.add_quiz_button)
        feedback = view.findViewById(R.id.add_quiz_feedback)
        quizIdText = view.findViewById(R.id.add_quiz_id)

        buttonOne = view.findViewById(R.id.option_one_button)
        buttonTwo = view.findViewById(R.id.option_two_button)
        buttonThree = view.findViewById(R.id.option_three_button)
        buttonFour = view.findViewById(R.id.option_four_button)
        buttonFive = view.findViewById(R.id.option_five_button)

        addOptionButton = view.findViewById(R.id.add_quiz_add_option_button)
        removeOptionButton = view.findViewById(R.id.add_quiz_remove_option_button)

        buttonOne.setOnClickListener(this)
        buttonTwo.setOnClickListener(this)
        buttonThree.setOnClickListener(this)
        buttonFour.setOnClickListener(this)
        addOptionButton.setOnClickListener(this)
        removeOptionButton.setOnClickListener(this)

        timerSpinner = view.findViewById(R.id.add_quiz_timer)

        if (quizType == "Exam Mode"){
            timerSpinner.visibility = View.INVISIBLE
        }else{
            timerSpinner.visibility = View.VISIBLE
        }

        ArrayAdapter.createFromResource(
            requireContext(),
            R.array.quiz_timer,android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            timerSpinner.adapter = adapter
        }

        timerSpinner.onItemSelectedListener = this

        button.setOnClickListener {
            saveQuestion()
        }

        removeOptionButton.visibility = View.INVISIBLE

    }

    @RequiresApi(Build.VERSION_CODES.CUPCAKE)
    private fun saveQuestion() {

        val question = questionText.editableText.toString()
        val option1 = optionOne.editableText.toString()
        val option2 = optionTwo.editableText.toString()
        val option3 = optionThree.editableText?.toString() ?: "null"
        val option4 = optionFour.editableText?.toString() ?: "null"
        val option5 = optionFive.editableText?.toString() ?: "null"
        val description = descriptionText.editableText.toString()

        quizIdText.text = quizId

        val questionModel = QuestionModel(questionId = questionId, question = question, option_a = option1, option_b = option2,option_c = option3, option_d = option4,option_e = option5,
            answer = answer, timer =  realTimer, description = description)

        Log.i("AddQuizFragment", "Question Model -> ${questionModel}")
        if (question.isNotEmpty() && option1.isNotEmpty() && option2.isNotEmpty() && answer != "") {
            firebaseFirestore.collection("quizlist").document(quizId)
                .collection("Questions").document(questionId).set(questionModel)
                .addOnCompleteListener {
                    if (it.isSuccessful) {
                        feedback.text = "Added Questions Successfully"
                        clearFields()
                        val action = AddQuizFragmentDirections.actionAddQuizFragmentToAddQuizListFragment()
                        action.quizId = quizId
                        navController.navigate(action)
                    } else {
                        feedback.text = "Error in Uploading => ${it.exception?.message}"
                    }

                }
        } else {
            questionText.error = "Input Question Title"
            optionOne.error = "Input Option One"
            optionTwo.error = "Input Option Two"
        }

    }

    private fun clearFields() {
        questionText.setText("")
        optionOne.setText("")
        optionTwo.setText("")
        optionThree.setText("")
        optionFour.setText("")
        buttonOne.setBackgroundColor(resources.getColor(R.color.lightGrey))
        buttonTwo.setBackgroundColor(resources.getColor(R.color.lightGrey))
        buttonThree.setBackgroundColor(resources.getColor(R.color.lightGrey))
        buttonFour.setBackgroundColor(resources.getColor(R.color.lightGrey))
        buttonFive.setBackgroundColor(resources.getColor(R.color.lightGrey))
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.option_one_button -> {
                answer = optionOne.editableText.toString()
                Log.i("AddQuizFragment", "saveQuestion: Option One $answer")
                buttonOne.setBackgroundColor(resources.getColor(R.color.green,null))
                buttonTwo.setBackgroundColor(resources.getColor(R.color.lightGrey,null))
                buttonThree.setBackgroundColor(resources.getColor(R.color.lightGrey,null))
                buttonFour.setBackgroundColor(resources.getColor(R.color.lightGrey,null))
                buttonFive.setBackgroundColor(resources.getColor(R.color.lightGrey,null))
            }
            R.id.option_two_button -> {
                answer = optionTwo.editableText.toString()
                Log.i("AddQuizFragment", "saveQuestion: Option Two $answer")
                buttonOne.setBackgroundColor(resources.getColor(R.color.lightGrey, null))
                buttonTwo.setBackgroundColor(resources.getColor(R.color.green, null))
                buttonThree.setBackgroundColor(resources.getColor(R.color.lightGrey, null))
                buttonFour.setBackgroundColor(resources.getColor(R.color.lightGrey, null))
                buttonFive.setBackgroundColor(resources.getColor(R.color.lightGrey,null))
            }
            R.id.option_three_button -> {
                answer = optionThree.editableText.toString()
                Log.i("AddQuizFragment", "saveQuestion: Option Three $answer")
                buttonOne.setBackgroundColor(resources.getColor(R.color.lightGrey, null))
                buttonTwo.setBackgroundColor(resources.getColor(R.color.lightGrey, null))
                buttonThree.setBackgroundColor(resources.getColor(R.color.green, null))
                buttonFour.setBackgroundColor(resources.getColor(R.color.lightGrey, null))
                buttonFive.setBackgroundColor(resources.getColor(R.color.lightGrey,null))
            }
            R.id.option_four_button -> {
                answer = optionFour.editableText.toString()
                Log.i("AddQuizFragment", "saveQuestion: Option Four $answer")
                buttonOne.setBackgroundColor(resources.getColor(R.color.lightGrey)) //= resources.getDrawable(R.color.red,null)
                buttonTwo.setBackgroundColor(resources.getColor(R.color.lightGrey))// = resources.getDrawable(R.color.red,null)
                buttonThree.setBackgroundColor(resources.getColor(R.color.lightGrey))//= resources.getDrawable(R.color.red,null)
                buttonFour.setBackgroundColor(resources.getColor(R.color.green))//= resources.getDrawable(R.color.green,null)
                buttonFive.setBackgroundColor(resources.getColor(R.color.lightGrey,null))
            }
            R.id.option_five_button -> {
                answer = optionFive.editableText.toString()
                Log.i("AddQuizFragment", "saveQuestion: Option Five $answer")
                buttonOne.setBackgroundColor(resources.getColor(R.color.lightGrey)) //= resources.getDrawable(R.color.red,null)
                buttonTwo.setBackgroundColor(resources.getColor(R.color.lightGrey))// = resources.getDrawable(R.color.red,null)
                buttonThree.setBackgroundColor(resources.getColor(R.color.lightGrey))//= resources.getDrawable(R.color.red,null)
                buttonFour.setBackgroundColor(resources.getColor(R.color.lightGrey))//= resources.getDrawable(R.color.green,null)
                buttonFive.setBackgroundColor(resources.getColor(R.color.green))
            }

            R.id.add_quiz_add_option_button -> {
                currentOption++
                when (currentOption) {
                    2 -> {
                        addOptionButton.visibility = View.VISIBLE
                        removeOptionButton.visibility = View.INVISIBLE
                    }
                    3 -> {
                        optionThree.visibility = View.VISIBLE
                        optionThreeLayout.visibility = View.VISIBLE
                        buttonThree.visibility = View.VISIBLE
                        addOptionButton.visibility = View.VISIBLE
                        removeOptionButton.visibility = View.VISIBLE
                    }
                    4 -> {
                        optionFour.visibility = View.VISIBLE
                        optionFourLayout.visibility = View.VISIBLE
                        buttonFour.visibility = View.VISIBLE
                        addOptionButton.visibility = View.VISIBLE
                        removeOptionButton.visibility = View.VISIBLE
                    }
                    5 -> {
                        optionFive.visibility = View.VISIBLE
                        optionFiveLayout.visibility = View.VISIBLE
                        buttonFive.visibility = View.VISIBLE
                        addOptionButton.visibility = View.INVISIBLE
                        removeOptionButton.visibility = View.VISIBLE
                    }
                }
            }
            R.id.add_quiz_remove_option_button -> {
                when (currentOption) {
                    5 -> {
                        currentOption--
                        optionFive.visibility = View.INVISIBLE
                        optionFiveLayout.visibility = View.INVISIBLE
                        buttonFive.visibility = View.INVISIBLE
                        addOptionButton.visibility = View.INVISIBLE
                        removeOptionButton.visibility = View.VISIBLE
                    }
                    4 -> {
                        currentOption--
                        optionFour.visibility = View.INVISIBLE
                        optionFourLayout.visibility = View.INVISIBLE
                        buttonFour.visibility = View.INVISIBLE
                        addOptionButton.visibility = View.INVISIBLE
                        removeOptionButton.visibility = View.VISIBLE
                    }
                    3 -> {
                        currentOption--
                        optionThree.visibility = View.INVISIBLE
                        optionThreeLayout.visibility = View.INVISIBLE
                        buttonThree.visibility = View.INVISIBLE
                        addOptionButton.visibility = View.VISIBLE
                        removeOptionButton.visibility = View.VISIBLE
                    }
                    2 -> {
                        removeOptionButton.visibility = View.INVISIBLE
                        addOptionButton.visibility = View.VISIBLE
                    }
                }
            }
        }
    }

    override fun onNothingSelected(parent: AdapterView<*>?) {

    }

    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
//        val spinner = parent as Spinner
//        if(spinner.id == R.id.add_quiz_timer){
            timer = parent?.getItemAtPosition(position) as String
            realTimer = timer.toLong()
        Log.i("AddQuizFragment", "This is the Timer -> ${timer} , RealTimer -> ${realTimer}")
        //}
    }

}