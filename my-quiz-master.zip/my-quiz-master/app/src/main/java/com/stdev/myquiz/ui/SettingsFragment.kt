package com.stdev.myquiz.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.google.android.gms.tasks.Continuation
import com.google.android.gms.tasks.Task
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.UploadTask
import com.stdev.myquiz.R
import de.hdodenhof.circleimageview.CircleImageView


class SettingsFragment : Fragment() {
    //Firebase
    private lateinit var firebaseFirestore: FirebaseFirestore
    private lateinit var firebaseStorage: FirebaseStorage
    private lateinit var firebaseAuth: FirebaseAuth

    //Views
    private lateinit var settingsName: TextInputEditText
    private lateinit var settingsImage: CircleImageView
    private lateinit var settingsButton: Button

    //Variables
    private var userId: String = ""
    private var filePath: Uri? = null
    private var storageReference: StorageReference? = null
    private var imageUrl: String = ""

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_settings,container,false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        firebaseFirestore = FirebaseFirestore.getInstance()
        firebaseStorage = FirebaseStorage.getInstance()
        storageReference = FirebaseStorage.getInstance().reference
        firebaseAuth = FirebaseAuth.getInstance()//upload Image

        userId = firebaseAuth.currentUser?.uid!!

        settingsName = view.findViewById(R.id.settings_name)
        settingsImage = view.findViewById(R.id.settings_image)
        settingsButton = view.findViewById(R.id.settings_button)

        firebaseFirestore.collection("users").document(userId).get()
            .addOnSuccessListener { snapshot ->
                val name = snapshot["name"]
                val image = snapshot["imageUrl"]

                Glide.with(this)
                    .load(image)
                    .into(settingsImage)
                settingsName.setText("$name")
            }.addOnFailureListener { exception ->
            //Handle error
        }

        settingsImage.setOnClickListener {
            val galleryIntent = Intent()
            galleryIntent.type = "image/*"
            galleryIntent.action = Intent.ACTION_GET_CONTENT
            startActivityForResult(Intent.createChooser(galleryIntent, "Select Image "), GALLERY_PICK)
            uploadImage()
        }


        settingsButton.setOnClickListener {
            //UploadName
            val name = settingsName.editableText.toString()
            val hashMap = HashMap<String, Any>()
            hashMap["name"] = name
            firebaseFirestore.collection("users").document(userId).update(hashMap)
        }

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == GALLERY_PICK && resultCode == Activity.RESULT_OK) {
            if (data == null || data.data == null) {
                return
            }

            filePath = data.data
            try {
                val bitmap = MediaStore.Images.Media.getBitmap(context?.contentResolver, filePath)
                settingsImage.setImageBitmap(bitmap)
            } catch (error: Exception) {
                //Print Error
                Toast.makeText(context, "${error.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    companion object {
        const val GALLERY_PICK = 1
    }

    private fun uploadImage() {
        if (filePath != null) {
            val ref = storageReference?.child("ProfileImage/$userId")
            val uploadTask = ref?.putFile(filePath!!)
            uploadTask?.continueWithTask(Continuation<UploadTask.TaskSnapshot, Task<Uri>> { task ->
                if (!task.isSuccessful) {
                    task.exception?.let {
                        throw it
                    }
                }
                return@Continuation ref.downloadUrl
            })?.addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val downloadUrl = task.result
                    addUploadRecordToDatabase(downloadUrl.toString())
                } else {
                    //HandleFailures
                    Toast.makeText(context, "${task.exception?.message}", Toast.LENGTH_SHORT).show()
                }
            }?.addOnFailureListener {
                //Handle Exception
                Toast.makeText(context, "${it.message}", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "Please Upload an Image", Toast.LENGTH_SHORT).show()
        }
    }

    private fun addUploadRecordToDatabase(uri: String) {
        val data = HashMap<String, Any>()
        data["imageUrl"] = uri

        firebaseFirestore.collection("users").document(userId).update(data)
            .addOnSuccessListener { documentReference ->
                Toast.makeText(context, "Saved to the Database", Toast.LENGTH_SHORT).show()
            }.addOnFailureListener {
            Toast.makeText(context, "Error =>${it.message}", Toast.LENGTH_SHORT).show()
        }
    }
}