package com.stdev.myquiz.viewmodel
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.stdev.myquiz.models.ProfileListModel
import com.stdev.myquiz.viewmodel.FirebaseRepository.OnFirestoreTaskComplete
import com.stdev.myquiz.models.QuizListModel


class QuizListViewModel : ViewModel(), OnFirestoreTaskComplete {
    private val quizListModelData = MutableLiveData<List<QuizListModel>>()
    private val firebaseRepository = FirebaseRepository(this)

    init {
        firebaseRepository.getQuizData()
    }

    fun getQuizListModelData(): LiveData<List<QuizListModel>> {
        firebaseRepository.getQuizData()//Todo changed this shii
        return quizListModelData
    }

    override fun quizListDataAdded(quizList: List<QuizListModel>) {
        quizListModelData.value = quizList
    }

    override fun profileListDataAdded(profileList: List<ProfileListModel>) {

    }

    override fun onError(e: Exception) {
        Log.d("QuizListViewModel", "onError: ${e.message}")
    }
}