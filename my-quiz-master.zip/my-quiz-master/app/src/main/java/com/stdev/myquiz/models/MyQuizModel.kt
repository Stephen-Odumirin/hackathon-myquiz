package com.stdev.myquiz.models

import com.google.firebase.firestore.DocumentId

class MyQuizModel (
    @DocumentId
    var quiz_id : String? = "null",
    var name : String? = "null",
    var description : String? = "null",
    var image : String? = "null",
    var level : String? = "null",
    var questions : Long? = 0L,
    var quizType : String? = "null"
)