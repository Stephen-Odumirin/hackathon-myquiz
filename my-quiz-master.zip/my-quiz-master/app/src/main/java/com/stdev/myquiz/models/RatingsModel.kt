package com.stdev.myquiz.models

data class RatingsModel (
    var userId : String? = "null",
    var rating : Double = 0.0,
    var name : String? = "null",
    var imageUrl : String? = "null",
    var comment : String? = "null"
)