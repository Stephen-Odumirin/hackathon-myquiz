package com.stdev.myquiz.ui.exam

import android.os.Bundle
import android.os.CountDownTimer
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.OnBackPressedCallback

import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.navigation.fragment.NavHostFragment.findNavController

import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.stdev.myquiz.R
import com.stdev.myquiz.models.QuestionModel
import com.stdev.myquiz.ui.calculator.CalculatorFragment
import com.stdev.myquiz.ui.showToast

class ExamFragment : Fragment() , View.OnClickListener{

    private lateinit var firebaseFirestore : FirebaseFirestore
    private lateinit var firebaseAuth : FirebaseAuth
    private lateinit var navController : NavController

    //Views
    private lateinit var examNumber : TextView
    private lateinit var examTimer : TextView
    private lateinit var examProgress : ProgressBar
    private lateinit var examQuestion : TextView
    private lateinit var examLayoutOne : LinearLayout
    private lateinit var examOptionOne : TextView
    private lateinit var examLayoutTwo : LinearLayout
    private lateinit var examOptionTwo : TextView
    private lateinit var examLayoutThree : LinearLayout
    private lateinit var examOptionThree : TextView
    private lateinit var examLayoutFour : LinearLayout
    private lateinit var examOptionFour : TextView
    private lateinit var examOptionFive : TextView
    private lateinit var examLayoutFive : LinearLayout
    private lateinit var examPreviousButton : MaterialButton
    private lateinit var examNextButton : MaterialButton

    private lateinit var examSubmit : TextView
    private lateinit var examCalculator : ImageView

    private var countDownTimer : CountDownTimer? = null

    //Variables
    private var quizId = ""
    private var currentQuestion = 0
    private var currentUser = ""
    private var totalQuestionsToAnswer = 0L
    private var quizTime = 0L
    private var allQuestionsList :List<QuestionModel> = ArrayList()
    private var answers : MutableList<Any?> = ArrayList()
    private var username = ""
    private var userimage = ""
    private var useremail = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_exam, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        firebaseAuth = FirebaseAuth.getInstance()
        firebaseFirestore = FirebaseFirestore.getInstance()
        navController = Navigation.findNavController(view)

        (activity as AppCompatActivity).supportActionBar?.setDisplayHomeAsUpEnabled(false)

        //Initialise Views
        initViews(view)

        //Get Quiz Id
        currentUser = firebaseAuth.currentUser?.uid!!
        quizId = ExamFragmentArgs.fromBundle(requireArguments()).quizId //"s2Zo5KtTlTGKZtXuWTZv"//"s2Zo5KtTITGKZtXuWTZvl" //
        totalQuestionsToAnswer = ExamFragmentArgs.fromBundle(requireArguments()).totalQuestions //
        quizTime = ExamFragmentArgs.fromBundle(requireArguments()).quizTime

        loadSomeStuffs()

        getQuestions()

        startTimer()
        examProgress.max = allQuestionsList.size
        examProgress.progress = answers.size
        //todo examProgress.progressTintList = ColorStateList(arrayOf(android.R.color.black,android.R.color.background_dark))

        examLayoutOne.setOnClickListener(this)
        examLayoutTwo.setOnClickListener(this)
        examLayoutThree.setOnClickListener(this)
        examLayoutFour.setOnClickListener(this)
        examLayoutFive.setOnClickListener(this)
        examNextButton.setOnClickListener(this)
        examPreviousButton.setOnClickListener(this)
        examCalculator.setOnClickListener(this)
        examSubmit.setOnClickListener(this)

        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner,object : OnBackPressedCallback(true){
            override fun handleOnBackPressed() {
                MaterialAlertDialogBuilder(requireContext())
                .setMessage("Exiting this Quiz would score you 0 % automatically\nAre you sure you want to continue ? ")
                .setNegativeButton("Stay"){_,_->}
                .setPositiveButton("Exit"){_,_->
                    findNavController(this@ExamFragment).navigateUp()
                }.show()
            }

        })

    }

    private fun getQuestions() {
        if (totalQuestionsToAnswer != 0L) {
            firebaseFirestore.collection("quizlist").document(quizId).collection("Questions").get()
                .addOnSuccessListener {
                    allQuestionsList = it.toObjects(QuestionModel::class.java)
                    answers = allQuestionsList.toMutableList()
                    //pickQuestions()
                    loadQuestion(1)
                    Log.i(
                        "ExamFragment",
                        "Success => $allQuestionsList \n \n New Answers => $answers"
                    )
                }.addOnFailureListener {
                    Log.i("ExamFragment", "Error => ${it.message}")
                    showToast(requireContext(), "Error => ${it.message}")
                }
        } else {
            showToast(requireContext(), "Error Getting the Quizz")
        }
    }

    private fun startTimer() {
        countDownTimer = object : CountDownTimer(quizTime.times(60000),10){
            override fun onFinish() {
                context?.let{
                    submitExam()
                }
            }

            override fun onTick(millisUntilFinished: Long) {
                examTimer.text = "Time Left : ${millisUntilFinished / 1000}"
            }

        }
        countDownTimer?.start()
    }

    private fun loadSomeStuffs(){
        firebaseFirestore.collection("users").document(currentUser).get().addOnCompleteListener {
            username = it.result.get("name") as String? ?: "null"
            userimage = it.result.get("imageUrl") as String? ?: "null"
            useremail = it.result.get("email") as String? ?: "null"
        }
    }

    private fun submitExam() {
        var score = 0
        Log.i("ExamFragment", "AllQuestionsList -> $allQuestionsList \n \n AnswersList -> $answers")
        for(i in allQuestionsList.indices){
            //val answer = allQuestionsList[i].answer
            if (answers[i] != null && answers[i] == allQuestionsList[i].answer){
                score++
            }
        }

        val resultMap = HashMap<String,Any>()
        resultMap["name"] = username
        resultMap["imageUrl"] = userimage
        resultMap["email"] = useremail
        resultMap["score"] = score.toLong()
        resultMap["totalQuestions"] = totalQuestionsToAnswer
        resultMap["percent"] = (score / totalQuestionsToAnswer) * 100

        firebaseFirestore.collection("quizlist").document(quizId).collection("Results")
            .document(currentUser)
            .set(resultMap)
            .addOnCompleteListener {
                if(it.isSuccessful){
                    MaterialAlertDialogBuilder(requireContext())
                        .setMessage("Submitted Successfully !!!")
                        .setCancelable(false)
                        .setPositiveButton("Exit"){_,_->
                            findNavController(this@ExamFragment).navigateUp()
                        }.show()
                }else {
                    MaterialAlertDialogBuilder(requireContext())
                        .setMessage("Submission Failed... Try again.")
                        .setCancelable(true)
                        .setPositiveButton("Okay"){_,_->

                        }.show()
                }
            }
    }

    private fun initViews(view: View) {
        examNumber = view.findViewById(R.id.exam_number)
        examQuestion = view.findViewById(R.id.exam_question)
        examTimer = view.findViewById(R.id.exam_timer)
        examProgress = view.findViewById(R.id.exam_progress)
        examLayoutOne = view.findViewById(R.id.exam_layout_one)
        examLayoutTwo = view.findViewById(R.id.exam_layout_two)
        examLayoutThree = view.findViewById(R.id.exam_layout_three)
        examLayoutFour = view.findViewById(R.id.exam_layout_four)
        examOptionOne = view.findViewById(R.id.exam_option_one)
        examOptionTwo = view.findViewById(R.id.exam_option_two)
        examOptionThree = view.findViewById(R.id.exam_option_three)
        examOptionFour = view.findViewById(R.id.exam_option_four)
        examOptionFive = view.findViewById(R.id.exam_option_five)
        examLayoutFive = view.findViewById(R.id.exam_layout_five)
        examPreviousButton = view.findViewById(R.id.exam_previous_button)
        examNextButton = view.findViewById(R.id.exam_next_button)
        examSubmit = view.findViewById(R.id.exam_submit)
        examCalculator = view.findViewById(R.id.exam_calculator)
    }

    private fun loadQuestion(questionNumber: Int) {
        //Set Question Number
        examNumber.text = "Question $questionNumber / ${allQuestionsList.size}"
        //Load Question Text
        examQuestion.text = allQuestionsList[questionNumber -1].question

        //Load Options
        examOptionOne.text = allQuestionsList[questionNumber -1].option_a
        examOptionTwo.text = allQuestionsList[questionNumber -1].option_b

        val option_c = allQuestionsList[questionNumber -1].option_c
        val option_d = allQuestionsList[questionNumber -1].option_d
        val option_e = allQuestionsList[questionNumber -1].option_e

        if(option_c == "null" || option_c == "" || option_c.isNullOrEmpty()){
            examOptionThree.visibility = View.INVISIBLE
            examLayoutThree.visibility = View.INVISIBLE
        }else{
            examOptionThree.visibility = View.VISIBLE
            examLayoutThree.visibility = View.VISIBLE
            examOptionThree.text = option_c
        }
        if(option_d == "null" || option_d == "" || option_d.isNullOrEmpty()){
            examOptionFour.visibility = View.INVISIBLE
            examLayoutFour.visibility = View.INVISIBLE
        }else{
            examOptionFour.visibility = View.VISIBLE
            examLayoutFour.visibility = View.VISIBLE
            examOptionFour.text = option_d
        }
        if(option_e == "null" || option_e == "" || option_e.isNullOrEmpty()){
            examOptionFive.visibility = View.INVISIBLE
            examLayoutFive.visibility = View.INVISIBLE
        }else {
            examOptionFive.visibility = View.VISIBLE
            examLayoutFive.visibility = View.VISIBLE
            examOptionFive.text = option_e
        }

        currentQuestion = questionNumber
        if(currentQuestion == totalQuestionsToAnswer.toInt()){
            examNextButton.text = "Finish"
        }else{
            examNextButton.text = "Next"
        }
    }

    override fun onClick(v: View?) {
        when(v?.id){
            R.id.exam_submit -> {
                MaterialAlertDialogBuilder(requireContext())
                    .setMessage("Are you sure you want to submit ? ")
                    .setNegativeButton("No"){_,_->}
                    .setPositiveButton("Yes"){_,_->
                        submitExam()
                    }.show()
            }
            R.id.exam_calculator -> {
                val dialog = CalculatorFragment()
                dialog.show(childFragmentManager,"calculatorFragment2")
            }
            R.id.exam_next_button -> {
                if(currentQuestion == totalQuestionsToAnswer.toInt()){
                    MaterialAlertDialogBuilder(requireContext())
                        .setMessage("Are you sure you want to submit ? ")
                        .setNegativeButton("No"){_,_->}
                        .setPositiveButton("Yes"){_,_->
                            submitExam()
                        }.show()
                }else{
                    examNextButton.text = "Next"
                    currentQuestion++
                    clearStuffs()
                    Log.i("ExamFragment", "AnswerList -> $answers CurrentQuestion -> $currentQuestion")
                    loadQuestion(currentQuestion)
                    checkStuffs(currentQuestion)
                }
            }
            R.id.exam_previous_button -> {
                if(currentQuestion != 1){
                    currentQuestion--
                    Log.i("ExamFragment", "AnswerList -> $answers CurrentQuestion -> $currentQuestion")
                    loadQuestion(currentQuestion)
                    checkStuffs(currentQuestion)
                }
            }
            R.id.exam_layout_one -> {
                answers[currentQuestion -1] = "${examOptionOne.text}"
                examLayoutOne.background = resources.getDrawable(R.drawable.option_selected,null)
                examLayoutTwo.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutThree.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutFour.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutFive.background = resources.getDrawable(R.drawable.option_unselected,null)
            }
            R.id.exam_layout_two -> {
                answers[currentQuestion -1] = "${examOptionTwo.text}"
                examLayoutOne.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutTwo.background = resources.getDrawable(R.drawable.option_selected,null)
                examLayoutThree.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutFour.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutFive.background = resources.getDrawable(R.drawable.option_unselected,null)
            }
            R.id.exam_layout_three -> {
                answers[currentQuestion -1] = "${examOptionThree.text}"
                examLayoutOne.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutTwo.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutThree.background = resources.getDrawable(R.drawable.option_selected,null)
                examLayoutFour.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutFive.background = resources.getDrawable(R.drawable.option_unselected,null)
            }
            R.id.exam_layout_four -> {
                answers[currentQuestion -1] = "${examOptionFour.text}"
                examLayoutOne.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutTwo.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutThree.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutFour.background = resources.getDrawable(R.drawable.option_selected,null)
                examLayoutFive.background = resources.getDrawable(R.drawable.option_unselected,null)

            }
            R.id.exam_layout_five -> {
                answers[currentQuestion -1] = "${examOptionFive.text}"
                examLayoutOne.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutTwo.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutThree.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutFour.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutFive.background = resources.getDrawable(R.drawable.option_selected,null)
            }

        }
    }

    private fun checkStuffs(number : Int){
        when {
            answers.getOrNull(number -1) == true -> {
                Log.i("ExamFragment","TestingStuff \n List -> $answers \n Null Case. Expected -> ${answers[number -1 ]} Got -> null")
                examLayoutOne.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutTwo.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutThree.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutFour.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutFive.background = resources.getDrawable(R.drawable.option_unselected,null)
            }
            answers[number -1] == examOptionOne.text -> {
                Log.i("ExamFragment","TestingStuff \n List -> $answers \n Case One. Expected ${answers[number -1]} Got -> ${examOptionOne.text}")
                examLayoutOne.background = resources.getDrawable(R.drawable.option_selected,null)
                examLayoutTwo.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutThree.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutFour.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutFive.background = resources.getDrawable(R.drawable.option_unselected,null)
            }
            answers[number -1] == examOptionTwo.text -> {
                Log.i("ExamFragment","TestingStuff \n List -> $answers \n Case Two. Expected ${answers[number -1]} Got -> ${examOptionTwo.text}")
                examLayoutOne.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutTwo.background = resources.getDrawable(R.drawable.option_selected,null)
                examLayoutThree.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutFour.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutFive.background = resources.getDrawable(R.drawable.option_unselected,null)
            }
            answers[number -1] == examOptionThree.text -> {
                Log.i("ExamFragment","TestingStuff \n List -> $answers \n Case Three. Expected ${answers[number -1]} Got -> ${examOptionThree.text}")
                examLayoutOne.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutTwo.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutThree.background = resources.getDrawable(R.drawable.option_selected,null)
                examLayoutFour.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutFive.background = resources.getDrawable(R.drawable.option_unselected,null)
            }
            answers[number -1] == examOptionFour.text -> {
                Log.i("ExamFragment","TestingStuff \n List -> $answers \n Case Four. Expected ${answers[number -1]} Got -> ${examOptionFour.text}")
                examLayoutOne.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutTwo.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutThree.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutFour.background = resources.getDrawable(R.drawable.option_selected,null)
                examLayoutFive.background = resources.getDrawable(R.drawable.option_unselected,null)
            }
            answers[number -1] == examOptionFive.text -> {
                Log.i("ExamFragment","TestingStuff \n List -> $answers \n Case Five. Expected ${answers[number -1]} Got -> ${examOptionFive.text}")
                examLayoutOne.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutTwo.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutThree.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutFour.background = resources.getDrawable(R.drawable.option_unselected,null)
                examLayoutFive.background = resources.getDrawable(R.drawable.option_selected,null)
            }
        }
    }

    private fun clearStuffs(){
        examLayoutOne.background = resources.getDrawable(R.drawable.option_unselected,null)
        examLayoutTwo.background = resources.getDrawable(R.drawable.option_unselected,null)
        examLayoutThree.background = resources.getDrawable(R.drawable.option_unselected,null)
        examLayoutFour.background = resources.getDrawable(R.drawable.option_unselected,null)
        examLayoutFive.background = resources.getDrawable(R.drawable.option_unselected,null)
    }

    override fun onResume() {
        super.onResume()
        (activity as AppCompatActivity).supportActionBar?.hide()
    }

    override fun onStop() {
        super.onStop()
        (activity as AppCompatActivity).supportActionBar?.show()
    }

}
