package com.stdev.myquiz.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import co.paystack.android.Paystack
import co.paystack.android.Paystack.TransactionCallback
import co.paystack.android.PaystackSdk
import co.paystack.android.Transaction
import co.paystack.android.model.Card
import co.paystack.android.model.Charge
import com.stdev.myquiz.R

class PaymentFragment : Fragment() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        PaystackSdk.initialize(context)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment

        val cardNumber = "5060666666666666666"
        val expiryMonth = 11
        val expiryYear = 21
        val cvv = "123"

        val card = Card(cardNumber,expiryMonth,expiryYear, cvv)
        if(card.isValid){
            //Charge Card
            val charge = Charge()
            charge.amount = 500
            charge.email = "Stephenodumirin@gmail.com"
            charge.currency = "NGN"
            charge.card = card

            PaystackSdk.chargeCard(activity,charge,object : TransactionCallback {
                override fun onSuccess(transaction: Transaction?) {
                    showToast(requireContext(),"Transaction Successful ${transaction.toString()}")
                }

                override fun beforeValidate(transaction: Transaction?) {
                    showToast(requireContext(),"Before Validate ${transaction.toString()}")
                }

                override fun onError(error: Throwable?, transaction: Transaction?) {
                    showToast(requireContext(),"Transaction Failed ${transaction.toString()} \nError -> ${error?.message}")
                }

            })

        }else {
            showToast(requireContext(),"Card not valid")
        }

        return inflater.inflate(R.layout.fragment_payment, container, false)
    }

}

