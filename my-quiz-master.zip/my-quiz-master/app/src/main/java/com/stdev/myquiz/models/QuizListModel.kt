package com.stdev.myquiz.models

import com.google.firebase.firestore.DocumentId
import java.lang.reflect.Constructor
import java.sql.Timestamp
import java.util.*

//let me test this shiii
data class QuizListModel (
    @DocumentId
    var quiz_id: String = "null",
    var name: String = "null",
    var description: String = "null",
    var image: String = "null",
    var level: String = "null",
    var visibility: String = "null",
    var questions: Long = 0L,
    var creator : String = "null",
    var timestamp : Long = 0L,
    var avgRating : Double = 0.0,
    var numRating : Int = 0,
    var timesTaken : Int = 0,
    var quizType : String = "null",
    var quizTime : Long = 0L,
    var pdf : String = "null"
)