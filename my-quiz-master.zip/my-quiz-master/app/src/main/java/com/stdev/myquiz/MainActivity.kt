package com.stdev.myquiz

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.ActionBar
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.drawerlayout.widget.DrawerLayout
import androidx.lifecycle.LiveData
import androidx.navigation.NavController
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.bumptech.glide.Glide
import com.google.android.material.navigation.NavigationView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.stdev.myquiz.ui.showToast
import de.hdodenhof.circleimageview.CircleImageView


class MainActivity : AppCompatActivity() {

    private lateinit var firebaseAuth: FirebaseAuth
    //private lateinit var bottomNavigationBar: BottomNavigationView
    private lateinit var navController: NavController
    private lateinit var mainNavigationView: NavigationView
    private lateinit var currentNavController: LiveData<NavController>
    private lateinit var appBarConfiguration : AppBarConfiguration

    private var firebaseFirestore: FirebaseFirestore? = null
    private lateinit var toolbar: Toolbar
    private var actionBar: ActionBar? = null
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var drawerToggle: ActionBarDrawerToggle

    private var userId = ""
    private var image = ""
    private var email = ""
    private var name = ""

    private var headerView: View? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val toolbar : Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        navController = findNavController(R.id.fragment_container)
        //bottomNavigationBar = findViewById(R.id.bottomNavigationView)
        firebaseFirestore = FirebaseFirestore.getInstance()
        firebaseAuth = FirebaseAuth.getInstance()
        mainNavigationView = findViewById(R.id.navigation_view)
        drawerLayout = findViewById(R.id.drawer_layout)
        drawerToggle = ActionBarDrawerToggle(this, drawerLayout, R.string.drawer_open, R.string.drawer_close)
        drawerToggle.syncState()

        userId = firebaseAuth.currentUser!!.uid

        appBarConfiguration = AppBarConfiguration(setOf(R.id.listFragment,R.id.myQuizFragment,R.id.profileFragment, R.id.searchFragment),drawerLayout)
        setupActionBarWithNavController(navController, appBarConfiguration)

        setNavHeader()

        //bottomNavigationBar.setupWithNavController(navController)
        mainNavigationView.setupWithNavController(navController)
        navController.addOnDestinationChangedListener { controller, destination, arguments ->
            when (destination.label.toString()) {
                "About Quiz" -> hide()
                "fragment_quiz" -> hide()
                "Quiz Result" -> hide()
                "Create New Quiz" -> hide()
                "Add Question" -> hide()
                "Edit Question" -> hide()
                "Home" -> show()
                "My Profile" -> show()
                "fragment_ask" -> show()
                "My Quizzes" -> show()
                "Search" -> show()
                "Leaderboard" -> hide()
                "Profile Settings" -> hide()
                "fragment_exam" -> hide()
                "fragment_practice" -> hide()
            }
        }
    }

    private fun setNavHeader() {
        firebaseFirestore!!.collection("users").document(userId).get()
            .addOnSuccessListener { document ->
                if (document != null && document.exists()) {
                    image = document["imageUrl"] as String? ?: "null"
                    name = document["name"] as String? ?: "null"
                    email = document["email"] as String? ?: "null"

                    val headerView = mainNavigationView.getHeaderView(0)
                    val username = headerView.findViewById<TextView>(R.id.nav_header_name)
                    val useremail = headerView.findViewById<TextView>(R.id.nav_header_email)
                    val userimage = headerView.findViewById<CircleImageView>(R.id.nav_header_image)

                    username.text = name
                    useremail.text = email

                    Glide.with(headerView)
                        .load(image)
                        .into(userimage)
                }
            }.addOnFailureListener {
                showToast(this, "Error -> ${it.message}")
            }
    }

    private fun show() {
        //bottomNavigationBar.visibility = View.VISIBLE
        drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED)

    }

    private fun hide() {
        //bottomNavigationBar.visibility = View.GONE
        drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED)
    }

    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
    }
}