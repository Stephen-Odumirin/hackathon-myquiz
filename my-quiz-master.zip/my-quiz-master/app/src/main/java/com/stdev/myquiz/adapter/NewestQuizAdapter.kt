package com.stdev.myquiz.adapter

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.firebase.ui.firestore.paging.FirestorePagingAdapter
import com.firebase.ui.firestore.paging.FirestorePagingOptions
import com.firebase.ui.firestore.paging.LoadingState
import com.stdev.myquiz.R
import com.stdev.myquiz.models.QuizListModel

//class NewestQuizAdapter (options: FirestorePagingOptions<QuizListModel>) :
//    FirestorePagingAdapter<QuizListModel, NewestQuizAdapter.NewestListViewHolder>(options) {
//
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NewestListViewHolder {
//        val view = LayoutInflater.from(parent.context)
//            .inflate(R.layout.single_list_item, parent, false)
//        return NewestListViewHolder(view)
//    }
//
//    override fun onBindViewHolder(
//        holder: NewestListViewHolder,
//        position: Int,
//        model: QuizListModel
//    ) {
//        holder.setNewestListData(model.name, model.level!!, model.image!!)
//        Log.i("ProfileFragment", "onBindViewHolder: Data ${model.name} ")
//    }
//
//
//    class NewestListViewHolder internal constructor(private val view: View) :
//        RecyclerView.ViewHolder(view) {
//        internal fun setNewestListData(quizName: String?, _quizLevel: String, _quizImage: String) {
//            val quizTitle = view.findViewById<TextView>(R.id.list_title)
//            val quizLevel = view.findViewById<TextView>(R.id.list_difficulty)
//            val quizImage = view.findViewById<ImageView>(R.id.list_image)
//
//
//            quizTitle.text = quizName //?: "null"
//            quizLevel.text = "$_quizLevel" //?: "null"
//
//            Glide.with(view).load(_quizImage).into(quizImage)
//        }
//
//    }
//
//    override fun onLoadingStateChanged(state: LoadingState) {
//        super.onLoadingStateChanged(state)
//        when(state){
//            LoadingState.LOADED -> Log.i("NewestQuizAdapter", "onLoadingStateChanged: Loaded $itemCount")
//            LoadingState.LOADING_INITIAL -> Log.i("NewestQuizAdapter", "onLoadingStateChanged: Loading Initial ")
//            LoadingState.ERROR -> Log.i("NewestQuizAdapter", "onLoadingStateChanged: Error")
//            LoadingState.FINISHED -> Log.i("NewestQuizAdapter", "onLoadingStateChanged: Finished ")
//            LoadingState.LOADING_MORE -> Log.i("NewestQuizAdapter", "onLoadingStateChanged: Loading More")
//
//        }
//    }
//}