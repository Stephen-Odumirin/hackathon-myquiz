package com.stdev.myquiz.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.paging.PagedList
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.firebase.ui.firestore.paging.FirestorePagingAdapter
import com.firebase.ui.firestore.paging.FirestorePagingOptions
import com.firebase.ui.firestore.paging.LoadingState
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.stdev.myquiz.R
import com.stdev.myquiz.models.QuestionModel

class AddQuizListFragment : Fragment() {

    private lateinit var firebaseFirestore : FirebaseFirestore
    private lateinit var firebaseAuth : FirebaseAuth
    private lateinit var listView : RecyclerView
    private lateinit var doneButton : MaterialButton
    private lateinit var exitButton : MaterialButton
    private lateinit var navController : NavController

    private lateinit var newButton: MaterialButton

    private var adapter : AddQuizAdapter? = null

    private var quizId = ""
    private var questionId = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_add_quiz_list, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        firebaseFirestore = FirebaseFirestore.getInstance()
        firebaseAuth = FirebaseAuth.getInstance()
        navController = Navigation.findNavController(view)

        quizId = AddQuizListFragmentArgs.fromBundle(requireArguments()).quizId

        listView = view.findViewById(R.id.add_quiz_list)
        newButton = view.findViewById(R.id.add_quiz_list_button_new)
        doneButton = view.findViewById(R.id.add_quiz_list_button_done)
        exitButton = view.findViewById(R.id.add_quiz_list_button_delete)

        val config = PagedList.Config.Builder()
            .setInitialLoadSizeHint(5)
            .setPageSize(5)
            .build()

        val listQuery : Query = firebaseFirestore.collection("quizlist").document(quizId).collection("Questions")

        val listOptions = FirestorePagingOptions.Builder<QuestionModel>()
            .setLifecycleOwner(this)
            .setQuery(listQuery,config,QuestionModel::class.java)
            .build()

        listView.layoutManager = LinearLayoutManager(context)
        adapter = AddQuizAdapter(listOptions)
        listView.adapter = adapter

        newButton.setOnClickListener {
            val id = firebaseFirestore.collection("quizlist").document(quizId).collection("Questions").document().id
            val action = AddQuizListFragmentDirections.actionAddQuizListFragmentToAddQuizFragment()
            action.questionId = id
            action.quizId = quizId
            navController.navigate(action)
        }

        doneButton.setOnClickListener {
            //done with the quiz button
            Toast.makeText(context, "Clicked on the Done Button", Toast.LENGTH_SHORT).show()
            firebaseFirestore.collection("quizlist").document(quizId).collection("Questions").get().addOnSuccessListener { querySnapshot ->
                val totalQuestions = querySnapshot.size()
                val hashMap = HashMap<String, Any>()
                hashMap["questions"] = totalQuestions.toLong()
                firebaseFirestore.collection("quizlist").document(quizId).update(hashMap).addOnSuccessListener {
                    MaterialAlertDialogBuilder(requireContext())
                        .setTitle("Copy Your Quiz Pin...")
                        .setIcon(R.drawable.ic_edit)
                        .setPositiveButton("Copy Quiz Pin"){_,_->
                            val clipboard = requireActivity().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip : ClipData = ClipData.newPlainText("Quiz Pin", quizId)
                            clipboard.setPrimaryClip(clip)
                            showToast(requireContext(), "Copied to your clipboard...")
                        }.show()
                    //navController.navigateUp()
                }.addOnFailureListener {
                    Toast.makeText(context, "Error -> ${it.message}",Toast.LENGTH_SHORT).show()
                }
            }.addOnFailureListener {
                Toast.makeText(context, "Error -> ${it.message}",Toast.LENGTH_SHORT).show()
            }

        }

        exitButton.setOnClickListener {
            //exit the quiz and delete the quiz
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Are you sure you want to Delete this Quiz ?")
                .setIcon(R.drawable.ic_delete)
                .setNegativeButton("No"){_,_ ->}
                .setPositiveButton("Yes"){_,_->
                    firebaseFirestore.collection("quizlist").document(quizId).delete().addOnSuccessListener {
                        Toast.makeText(context, "Deleted Successfully", Toast.LENGTH_SHORT).show()
                        navController.navigateUp()
                    }.addOnFailureListener {
                        Toast.makeText(context, "Error => ${it.message}",Toast.LENGTH_SHORT).show()
                    }
                }.show()
        }
    }

    private inner class AddQuizAdapter(options: FirestorePagingOptions<QuestionModel>) :
        FirestorePagingAdapter<QuestionModel, AddQuizAdapter.AddQuizViewHolder>(options) {


        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AddQuizViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.single_add_quiz_item, parent, false)
            return AddQuizViewHolder(view)
        }

        override fun onBindViewHolder(holder: AddQuizViewHolder, position: Int, model: QuestionModel) {
            holder.setListData(model.question,model.option_a,model.option_b,model.option_c,model.option_d,model.option_e,model.description,model.answer)

            holder.deleteButton.setOnClickListener {
                questionId = model.questionId!!
                MaterialAlertDialogBuilder(requireContext())
                    .setTitle("Are you sure you want to Delete this Question ? ")
                    .setIcon(R.drawable.ic_delete)
                    .setNegativeButton("No"){_,_ ->}
                    .setPositiveButton("Yes"){_,_->
                        firebaseFirestore.collection("quizlist").document(quizId).collection("Questions").document(questionId)
                            .delete().addOnSuccessListener {
                                showToast(requireContext(), "Deleted Successfully ")
                            }.addOnFailureListener {
                                showToast(requireContext(), "Error => ${it.message}")
                            }
                    }.show()
            }

            holder.editButton.setOnClickListener {
                //Navigate to the edit screen
                val questionId = model.questionId
                val action = AddQuizListFragmentDirections.actionAddQuizListFragmentToEditQuizFragment()
                action.questionId = "$questionId"
                action.quizId = quizId
                action.question = "${model.question}"
                action.optionA = "${model.option_a}"
                action.optionB = "${model.option_b}"
                action.optionC = "${model.option_c}"
                action.optionD = "${model.option_d}"
                action.optionE = "${model.option_e}"

                action.description = "${model.description}"
                navController.navigate(action)
            }
        }

        inner class AddQuizViewHolder(val view: View) : RecyclerView.ViewHolder(view) {

            internal fun setListData(question: String?, option_a: String?, option_b: String?, option_c : String? , option_d : String?,option_e : String? , description : String?,answer : String?) {
                val questionText = view.findViewById<TextView>(R.id.list_question_text)
                val optionOneText = view.findViewById<TextView>(R.id.list_option_one)
                val optionTwoText = view.findViewById<TextView>(R.id.list_option_two)
                val optionThreeText = view.findViewById<TextView>(R.id.list_option_three)
                val optionFourText = view.findViewById<TextView>(R.id.list_option_four)
                val optionFiveText = view.findViewById<TextView>(R.id.list_option_five)

                questionText.text = "$question"
                optionOneText.text = "$option_a"
                optionTwoText.text = "$option_b"

                if(option_c == "null" || option_c == "" || option_c.isNullOrEmpty()){
                    optionThreeText.visibility = View.INVISIBLE
                    listButtonThree.visibility = View.INVISIBLE
                }else {
                    optionThreeText.visibility = View.VISIBLE
                    listButtonThree.visibility = View.VISIBLE
                    optionThreeText.text = "$option_c"
                }

                if(option_d == "null" || option_d == "" || option_d.isNullOrEmpty()){
                    optionFourText.visibility = View.INVISIBLE
                    listButtonFour.visibility = View.INVISIBLE
                }else {
                    optionFourText.visibility = View.VISIBLE
                    listButtonFour.visibility = View.VISIBLE
                    optionFourText.text = "$option_d"
                }

                if(option_e == "null" || option_e == "" || option_e.isNullOrEmpty()){
                    optionFiveText.visibility = View.INVISIBLE
                    listButtonFive.visibility = View.INVISIBLE
                }else {
                    optionFiveText.visibility = View.VISIBLE
                    listButtonFive.visibility = View.VISIBLE
                    optionFiveText.text = "$option_e"
                }

                when {
                    answer == option_a -> {
                        listButtonOne.setBackgroundColor(resources.getColor(R.color.green,null))
                    }
                    answer == option_b -> {
                        listButtonTwo.setBackgroundColor(resources.getColor(R.color.green,null))
                    }
                    answer == option_c -> {
                        listButtonThree.setBackgroundColor(resources.getColor(R.color.green,null))
                    }
                    answer == option_d -> {
                        listButtonFour.setBackgroundColor(resources.getColor(R.color.green,null))
                    }
                    answer == option_e -> {
                        listButtonFive.setBackgroundColor(resources.getColor(R.color.green,null))
                    }
                }
            }

            val deleteButton : ImageView = view.findViewById(R.id.list_delete_question)
            val editButton : ImageView = view.findViewById(R.id.list_edit_question)
            val listButtonOne : ImageView = view.findViewById(R.id.list_button_one)
            val listButtonTwo : ImageView = view.findViewById(R.id.list_button_two)
            val listButtonThree : ImageView = view.findViewById(R.id.list_button_three)
            val listButtonFour : ImageView = view.findViewById(R.id.list_button_four)
            val listButtonFive : ImageView = view.findViewById(R.id.list_button_five)

        }

        override fun onLoadingStateChanged(state: LoadingState) {
            super.onLoadingStateChanged(state)
            when (state) {
                LoadingState.LOADED -> Log.i(
                    "AddQuizAdapter",
                    "onLoadingStateChanged: Loaded $itemCount"
                )
                LoadingState.LOADING_INITIAL -> Log.i(
                    "AddQuizAdapter",
                    "onLoadingStateChanged: Loading Initial "
                )
                LoadingState.ERROR -> Log.i("AddQuizAdapter", "onLoadingStateChanged: Error")
                LoadingState.FINISHED -> Log.i(
                    "AddQuizAdapter",
                    "onLoadingStateChanged: Finished "
                )
                LoadingState.LOADING_MORE -> Log.i(
                    "AddQuizAdapter",
                    "onLoadingStateChanged: Loading More"
                )

            }
        }

    }


}