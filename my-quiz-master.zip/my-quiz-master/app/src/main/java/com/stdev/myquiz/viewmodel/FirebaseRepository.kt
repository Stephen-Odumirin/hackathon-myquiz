package com.stdev.myquiz.viewmodel

import android.provider.ContactsContract
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.FirebaseFirestore
import com.stdev.myquiz.models.ProfileListModel
import com.stdev.myquiz.models.QuizListModel

//This class gets the data from firebase and passes it through an interface...
class FirebaseRepository (private val onFirestoreTaskComplete: OnFirestoreTaskComplete){

    private val firebaseFirestore: FirebaseFirestore = FirebaseFirestore.getInstance()
    private val quizReference = firebaseFirestore.collection("quizlist").whereEqualTo("visibility","public")

    fun getQuizData() {
        quizReference.get().addOnCompleteListener {
            if (it.isSuccessful) {
                onFirestoreTaskComplete.quizListDataAdded(it.result?.toObjects(QuizListModel::class.java)!!)
            } else {
                onFirestoreTaskComplete.onError(it.exception!!)
            }
        }
    }

    interface OnFirestoreTaskComplete{
        fun quizListDataAdded(quizList: List<QuizListModel>)
        fun profileListDataAdded(profileList: List<ProfileListModel>)
        fun onError(e: Exception)
    }


}