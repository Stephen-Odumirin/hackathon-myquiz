package com.stdev.myquiz.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputLayout
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.stdev.myquiz.MainActivity
import com.stdev.myquiz.R
import com.stdev.myquiz.models.UserModel

class SignUpActivity : AppCompatActivity() {

    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore

    private lateinit var signUpName: TextInputLayout
    private lateinit var signUpEmail: TextInputLayout
    private lateinit var signUpPassword: TextInputLayout
    private lateinit var confirmSignUpPassword: TextInputLayout
    private lateinit var signUpButton: MaterialButton
    private lateinit var signInButton: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        firebaseAuth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()

        signUpName = findViewById(R.id.signup_name)
        signUpEmail = findViewById(R.id.signup_email)
        signUpPassword = findViewById(R.id.signup_password)
        confirmSignUpPassword = findViewById(R.id.signup_password_two)
        signUpButton = findViewById(R.id.signup_button)
        signInButton = findViewById(R.id.signup_signin)

        signInButton.setOnClickListener {
            startActivity(Intent(this, SignInActivity::class.java))
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK and Intent.FLAG_ACTIVITY_CLEAR_TOP
            finish()
        }

        signUpButton.setOnClickListener {
            val name: String = signUpName.editText?.text.toString()
            val email: String = signUpEmail.editText?.text.toString()
            val password: String = signUpPassword.editText?.text.toString()
            val confirmPassword: String = confirmSignUpPassword.editText?.text.toString()

            if (name.isNotEmpty() and email.isNotEmpty() and (password == confirmPassword)) {
                firebaseAuth.createUserWithEmailAndPassword(email, password).addOnSuccessListener {
                    //User Created !
                    showToast(this, "User Created")
                    val user = firebaseAuth.currentUser?.uid
                    val userModel = UserModel(user!!, name, email)
                    firestore.collection("users").document(user).set(userModel)
                        .addOnSuccessListener {
                            //User Detail Saved !
                            showToast(this, "User Details Saved Successfully")
                            val intent = Intent(this, MainActivity::class.java)
                            startActivity(intent)
                            intent.flags =
                                Intent.FLAG_ACTIVITY_CLEAR_TASK and Intent.FLAG_ACTIVITY_CLEAR_TOP
                            finish()
                        }.addOnFailureListener {
                        //User Details Not Saved !
                        showToast(this, "User Details Not Saved => ${it.message}")
                    }
                }.addOnFailureListener {
                    //User Not Created !
                    showToast(this, "User Not Created => ${it.message}")
                }
            }
            if (name.isEmpty()) {
                signUpName.error = "Enter your name"
            }
            if (email.isEmpty()) {
                signUpEmail.error = "Enter a Valid Email Address"
            }
            if (password != confirmPassword) {
                confirmSignUpPassword.error = "Passwords Didn't match"
            }
        }

    }
}

fun showToast(context: Context, message: String) {
    Toast.makeText(context, message, Toast.LENGTH_LONG).show()
}
