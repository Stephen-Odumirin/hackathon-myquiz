package com.stdev.myquiz.ui.calculator

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.View.OnLongClickListener
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.stdev.myquiz.R
import kotlin.math.roundToInt


class CalculatorFragment : BottomSheetDialogFragment() , View.OnClickListener{

    private var resultShown = false
    private var one : Button? = null
    private var two : Button? = null
    private var three : Button? = null
    private var four : Button? = null
    private var five : Button? = null
    private var six : Button? = null
    private var seven : Button? = null
    private var eight : Button? = null
    private var nine : Button? = null
    private var zero : Button? = null
    private var dot : Button? = null
    private var clear : Button? = null
    private var plus : Button? = null
    private var minus : Button? = null
    private var division : Button? = null
    private var multiply : Button? = null
    private var equal : Button? = null
    private var prev : TextView? = null
    private var display : TextView? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        val view = inflater.inflate(R.layout.fragment_calculator,container,false)


        //val display: TextView = view.findViewById(R.id.display)
        //val history: TextView = view.findViewById(R.id.prev)
        //val clear: Button = view.findViewById(R.id.clear)

        prev = view.findViewById(R.id.prev)
        one = view.findViewById(R.id.one)
        two = view.findViewById(R.id.two)
        three = view.findViewById(R.id.three)
        four = view.findViewById(R.id.four)
        five = view.findViewById(R.id.five)
        six = view.findViewById(R.id.six)
        seven = view.findViewById(R.id.seven)
        eight = view.findViewById(R.id.eight)
        nine = view.findViewById(R.id.nine)
        zero = view.findViewById(R.id.zero)
        plus = view.findViewById(R.id.plus)
        minus = view.findViewById(R.id.minus)
        multiply = view.findViewById(R.id.multiply)
        division = view.findViewById(R.id.division)
        dot = view.findViewById(R.id.dot)
        equal = view.findViewById(R.id.equal)
        display = view.findViewById(R.id.display)
        clear = view.findViewById(R.id.clear)

        one?.setOnClickListener(this)
        two?.setOnClickListener(this)
        three?.setOnClickListener(this)
        four?.setOnClickListener(this)
        five?.setOnClickListener(this)
        six?.setOnClickListener(this)
        seven?.setOnClickListener(this)
        eight?.setOnClickListener(this)
        nine?.setOnClickListener(this)
        zero?.setOnClickListener(this)
        plus?.setOnClickListener(this)
        minus?.setOnClickListener(this)
        multiply?.setOnClickListener(this)
        division?.setOnClickListener(this)
        dot?.setOnClickListener(this)
        equal?.setOnClickListener(this)
        clear?.setOnClickListener(this)

        // Setting functionality for clear button to clear
        // both TextViews on holding this button.

        // Setting functionality for clear button to clear
        // both TextViews on holding this button.
        clear?.setOnLongClickListener(OnLongClickListener {
            display?.text = "0"
            prev?.text = ""
            true
        })

        return view
    }

    private fun operandClick(view: View) {
        val btn: Button = view.findViewById(view.id)
        //val display: TextView = view.findViewById(R.id.display)
        val dataOnDisplay = display?.text.toString()
        val btnData = btn.text.toString()

        // If display data is 0 or a result is shown
        // we set the display value to the value of the
        // operand clicked otherwise we append operand with
        // existing data
        if (dataOnDisplay == "0" || resultShown) {
            display?.text = btnData
            resultShown = false
        } else {
            val res = dataOnDisplay + btn.text.toString()
            display?.text = res
        }
    }

    private fun operatorClick(view: View) {
        //val display: TextView = view.findViewById(R.id.display)
        val btn: Button = view.findViewById(view.id)
        val displayText = display?.text.toString()
        if (resultShown) resultShown = false
        if (displayText == "Syntax Error" || displayText == "Infinity") display?.text =
            "0" + btn.text else display?.text =
            displayText + btn.text
    }

    private fun clear(view: View) {
        //val display: TextView = view.findViewById(R.id.display)
        val displayData = display?.text.toString()
        if (displayData == "0" || displayData == "Syntax Error" || displayData == "Infinity") display?.text =
            "0" else {
            var backSpacedData = displayData.substring(0, displayData.length - 1)
            if (backSpacedData == "") backSpacedData = "0"
            display?.text = backSpacedData
        }
    }

    private fun calculate(view: View) {
        //val display: TextView = view.findViewById(R.id.display)
        val textTransition: Animation = AnimationUtils.loadAnimation(context, R.anim.text_transition)
        //val history: TextView = view.findViewById(R.id.prev)
        prev?.startAnimation(textTransition)
        val equation = display?.text.toString().trim { it <= ' ' }
        val expressionEvaluation = ExpressionEvaluation()
        val result: Double? = expressionEvaluation.expressionEvaluation(equation)
        if (java.lang.Double.isNaN(result!!)) {
            display?.text = "Syntax Error"
        } else {
            prev?.text = equation
            when {
                result.toString().contains("E") -> {
                    display?.text = result.toString()
                }
                result == result.roundToInt().toDouble() -> {
                    val res = result.toString()
                    display?.text = res.substring(0, res.length - 2)
                }
                else -> display?.text = result.toString()
            }
        }
        resultShown = true
    }

    private fun dotClick(view: View) {
        //val display: TextView = view.findViewById(R.id.display)
        val dataOnDisplay = display?.text.toString()
        val len = dataOnDisplay.length
        val lastChar = dataOnDisplay[len - 1]
        if (resultShown) {
            resultShown = false
            display?.text = "0."
        } else {
            if ((lastChar in '1'..'9') || lastChar == '0') display?.text =
                "$dataOnDisplay." else if (lastChar == '+' || lastChar == '-' || lastChar == '\u00d7' // \u00d7 = multiplication character in unicode
                || lastChar == '\u00f7'
            ) // // \u00f7 = multiplication character in unicode
                display?.text = dataOnDisplay + "0."
        }
    }

    override fun onClick(view : View) {
        when(view.id){
            R.id.seven -> operandClick(view)
            R.id.eight -> operandClick(view)
            R.id.nine -> operandClick(view)
            R.id.four -> operandClick(view)
            R.id.five -> operandClick(view)
            R.id.six -> operandClick(view)
            R.id.one -> operandClick(view)
            R.id.two -> operandClick(view)
            R.id.three -> operandClick(view)
            R.id.dot -> dotClick(view)
            R.id.zero -> operandClick(view)
            R.id.clear -> clear(view)
            R.id.plus -> operatorClick(view)
            R.id.minus -> operatorClick(view)
            R.id.multiply -> operatorClick(view)
            R.id.division -> operatorClick(view)
            R.id.equal -> calculate(view)
        }
    }
}