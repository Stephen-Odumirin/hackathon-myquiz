package com.stdev.myquiz.models

import com.google.firebase.firestore.DocumentId

data class QuestionModel(
    //@DocumentId
    var questionId: String? = "null",
    var question: String? = "null",
    var option_a: String? = "null",
    var option_b: String? = "null",
    var option_c: String? = "null",
    var option_d: String? = "null",
    var option_e: String? = "null",
    var answer: String? = "null",
    var timer: Long? = 10L,
    var description: String? = "null"
)
