package com.stdev.myquiz.models

data class ProfileListModel(
    //@DocumentId
    var quiz_id: String? = "null",
    var quizTitle: String? = "null",
    var quizScore: Long? = 0L,
    var quizImage : String? = "null"
)
