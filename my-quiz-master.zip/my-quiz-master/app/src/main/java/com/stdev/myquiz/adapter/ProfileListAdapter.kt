package com.stdev.myquiz.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.stdev.myquiz.R
import com.stdev.myquiz.models.ProfileListModel

//
//class ProfileListAdapter(private val onProfileListItemClicked: OnProfileListItemClicked) :
//    RecyclerView.Adapter<ProfileListAdapter.ProfileViewHolder>() {
//
//    private var profileListModels: List<ProfileListModel>? = null
//    //private var onQuizListItemClicked : OnQuizListItemClicked
//
//    fun setProfileListModels(profileListModels: List<ProfileListModel>?) {
//        this.profileListModels = profileListModels
//    }
//
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProfileViewHolder {
//        val view: View =
//            LayoutInflater.from(parent.context).inflate(R.layout.single_result_item, parent, false)
//        return ProfileViewHolder(view)
//    }
//
//    override fun getItemCount(): Int {
//        return if (profileListModels == null) 0
//        else profileListModels!!.size
//    }
//
//    override fun onBindViewHolder(holder: ProfileViewHolder, position: Int) {
//        holder.profilelistTitle.text = profileListModels!![position].quizTitle
//        val imageUrl: String? = profileListModels!![position].quizImage
//        if (imageUrl != "null") {
//            holder.profilelistImage.visibility = View.VISIBLE
//            Glide.with(holder.itemView.context)
//                .load(imageUrl)
//                .centerCrop()
//                .placeholder(R.drawable.placeholder_image)
//                .into(holder.profilelistImage)
//        }
//        holder.profilelistScore.text = profileListModels!![position].quizScore.toString()
//    }
//
//    inner class ProfileViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView),
//        View.OnClickListener {
//        val profilelistImage: ImageView = itemView.findViewById(R.id.profile_list_image)
//        val profilelistTitle: TextView = itemView.findViewById(R.id.profile_list_title)
//        val profilelistScore: TextView = itemView.findViewById(R.id.profile_list_score)
//
//        override fun onClick(v: View) {
//            onProfileListItemClicked.onItemClicked(adapterPosition)
//        }
//
//        init {
//            itemView.setOnClickListener(this)
//        }
//    }
//
//    interface OnProfileListItemClicked {
//        fun onItemClicked(position: Int)
//    }
//}