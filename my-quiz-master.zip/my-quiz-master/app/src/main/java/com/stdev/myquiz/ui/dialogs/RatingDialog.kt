package com.stdev.myquiz.ui.dialogs

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.RatingBar
import com.google.android.gms.tasks.Task
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.material.button.MaterialButton
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.stdev.myquiz.R
import com.stdev.myquiz.models.QuizListModel
import com.stdev.myquiz.ui.showToast

class RatingDialog(private var quizId : String) : BottomSheetDialogFragment() {

    private lateinit var firebaseFirestore : FirebaseFirestore
    private lateinit var firebaseAuth : FirebaseAuth
    //private lateinit var navController : NavController

    private lateinit var editText : EditText
    private lateinit var ratingBar : RatingBar
    private lateinit var button : MaterialButton

    private var quizIdl = ""
    private var userId = ""
    private var username = ""
    private var userimage = ""

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
      return inflater.inflate(R.layout.rating_dialog,container,false)
  }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        firebaseFirestore = FirebaseFirestore.getInstance()
        firebaseAuth = FirebaseAuth.getInstance()
       // navController = Navigation.findNavController(requireView())

        userId = firebaseAuth.currentUser?.uid!!
        //quizId = MyDialogFragmentArgs.fromBundle(requireArguments()).quizId

        val quizRef = firebaseFirestore.collection("quizlist").document(quizId)

        getUserDetails()

        editText = view.findViewById(R.id.bottom_sheet_text)!!
        ratingBar = view.findViewById(R.id.bottom_sheet_ratingbar)!!
        button = view.findViewById(R.id.bottom_sheet_button)!!

        button.setOnClickListener {
            val text = editText.editableText.toString()
            val rating2 = ratingBar.rating
            if(text.isNotEmpty()){
                addRating(quizRef,rating2,text).addOnSuccessListener {
                    dismiss()
                    showToast(
                        requireContext(),
                        "Uploaded Successfully"
                    )
                    //navController.navigateUp()
                }.addOnFailureListener{
                    showToast(
                        requireContext(),
                        "Error -> ${it.message}"
                    )
                }
            }
        }
    }

//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
//
//        firebaseFirestore = FirebaseFirestore.getInstance()
//        firebaseAuth = FirebaseAuth.getInstance()
//        navController = Navigation.findNavController(requireView())
//
//        userId = firebaseAuth.currentUser?.uid!!
//        quizId = MyDialogFragmentArgs.fromBundle(requireArguments()).quizId
//
//        val quizRef = firebaseFirestore.collection("quizlist").document(quizId)
//
//        getUserDetails()
//
//        editText = view?.findViewById(R.id.bottom_sheet_text)!!
//        ratingBar = view?.findViewById(R.id.bottom_sheet_ratingbar)!!
//        button = view?.findViewById(R.id.bottom_sheet_button)!!
//
//        button.setOnClickListener {
//            val text = editText.editableText.toString()
//            val rating2 = ratingBar.rating
//            if(text.isNotEmpty()){
//                addRating(quizRef,rating2,text).addOnSuccessListener {
//                    dismiss()
//                    showToast(requireContext(), "Uploaded Successfully")
//                    //navController.navigateUp()
//                }.addOnFailureListener{
//                    showToast(requireContext(), "Error -> ${it.message}")
//                }
//            }
//        }
//
//        return builder.create()
//    }

//    override fun onActivityCreated(savedInstanceState: Bundle?) {
//        super.onActivityCreated(savedInstanceState)
//
//    }

    private fun getUserDetails() {
        firebaseFirestore.collection("users").document(userId).get().addOnCompleteListener {
            if(it.isSuccessful){
                val result = it.result
                if(result != null && result.exists()){
                    username = result.get("name") as String? ?: "null"
                    userimage = result.get("imageUrl") as String? ?: "null"
                }
            }
        }
    }

    private fun clearFields() {
        editText.setText("")
        ratingBar.rating = 0F
    }

    private fun addRating(quizRef : DocumentReference,rating : Float, text : String) : Task<Void>  {
        val ratingRef = quizRef.collection("Ratings").document(userId)
        return firebaseFirestore.runTransaction{transaction ->
            val quiz = transaction.get(quizRef).toObject(QuizListModel::class.java)//toObject<RatingsModel>()!!

            //Compute the new number of ratings
            val newNumRatings = quiz?.numRating?.plus(1)

            //Compute new Average Rating
            val oldRatingTotal = quiz?.avgRating?.times(quiz.numRating)
            val newAvgRating = (oldRatingTotal?.plus(rating))?.div(newNumRatings!!)

            //Set new Quiz Info
            quiz?.numRating = newNumRatings!!
            quiz.avgRating = newAvgRating!!

            //Update Quiz
            //Todo remodified the code below to my taste
            //transaction.set(quizRef , quiz)
            val data2 = hashMapOf<String, Any>()
                data2["numRating"] = newNumRatings
                data2["avgRating"] = newAvgRating

            transaction.set(quizRef , data2 , SetOptions.merge())

            //Update Rating
            val data = hashMapOf<String, Any>()
                data["userId"] = userId
                data["name"] = username
                data["imageUrl"] = userimage
                data["comment"] = text
                data["rating"] = rating

            transaction.set(ratingRef ,data, SetOptions.merge())
            Log.i("TestingRatingStuffs", "newNumRatings -> $newNumRatings , oldRatingTotal -> $oldRatingTotal , newAvgRating -> $newAvgRating")
            Log.i("TestingRatingStuffs", "userId -> $userId , name -> $username , imageUrl -> $userimage ,comment -> $text, rating -> $rating")
            null


        }
    }
}