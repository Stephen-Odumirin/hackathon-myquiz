package com.stdev.myquiz

import android.app.Application

class Application : Application() {

}