package com.stdev.myquiz.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputLayout
import com.google.firebase.auth.FirebaseAuth
import com.stdev.myquiz.MainActivity
import com.stdev.myquiz.R

class SignInActivity : AppCompatActivity() {

    private lateinit var firebaseAuth: FirebaseAuth

    private lateinit var signInEmail: TextInputLayout
    private lateinit var signInPassword: TextInputLayout
    private lateinit var signInButton: MaterialButton
    private lateinit var signUpButton: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signin)

        firebaseAuth = FirebaseAuth.getInstance()

        signInEmail = findViewById(R.id.signin_email)
        signInPassword = findViewById(R.id.signin_password)
        signInButton = findViewById(R.id.signin_button)
        signUpButton = findViewById(R.id.signin_signup)

        signUpButton.setOnClickListener {
            startActivity(Intent(this, SignUpActivity::class.java))
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK and Intent.FLAG_ACTIVITY_CLEAR_TOP
            finish()
        }

        signInButton.setOnClickListener {
            val email: String = signInEmail.editText?.text.toString()
            val password: String = signInPassword.editText?.text.toString()
            if (email.isNotEmpty() and password.isNotEmpty()) {
                firebaseAuth.signInWithEmailAndPassword(email, password).addOnSuccessListener {
                    //User Signed in Successfully
                    showToast(this, "Signed In Successfully")
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                    intent.flags =
                        Intent.FLAG_ACTIVITY_CLEAR_TASK and Intent.FLAG_ACTIVITY_CLEAR_TOP
                    finish()
                }.addOnFailureListener {
                    //User not Signed In
                    signInEmail.editText?.setText("")
                    signInPassword.editText?.setText("")
                    showToast(this, "Error in Signing in => ${it.message}")
                }
            }
            if (email.isEmpty()) {
                signInEmail.error = "Enter a valid Email Address"
            }
            if (password.isEmpty()) {
                signInPassword.error = "Enter your password"
            }
        }


    }
}