package com.stdev.myquiz.ui

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.firebase.ui.firestore.FirestoreRecyclerAdapter
import com.firebase.ui.firestore.FirestoreRecyclerOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.stdev.myquiz.R
import com.stdev.myquiz.models.ProfileListModel
import com.stdev.myquiz.viewmodel.ProfileListViewModel
import de.hdodenhof.circleimageview.CircleImageView

class ProfileFragment : Fragment() {

    private lateinit var firebaseFirestore: FirebaseFirestore
    private lateinit var firebaseAuth: FirebaseAuth
    private var adapter: ResultRecyclerAdapter? = null
    private lateinit var navController: NavController
    private var profileListModelTwo: List<ProfileListModel>? = null

    //Views
    private lateinit var profileName: TextView
    private lateinit var profileEmail: TextView
    private lateinit var profileListView: RecyclerView
    private lateinit var profileTotalQuizTaken: TextView
    private lateinit var profileTotalQuizCreated: TextView
    private lateinit var profileButton: Button
    private var profileImage: CircleImageView? = null
    private var totalQuizCreated = 0


    private lateinit var profileListViewModel: ProfileListViewModel

    private var userId = ""
    private var name = ""
    private var email = ""
    private var image = ""
    private var quizId = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_profile, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        firebaseAuth = FirebaseAuth.getInstance()
        firebaseFirestore = FirebaseFirestore.getInstance()
        profileName = view.findViewById(R.id.profile_name)
        profileEmail = view.findViewById(R.id.profile_email)
        profileListView = view.findViewById(R.id.profile_recycler_view)
        navController = Navigation.findNavController(view)

        profileTotalQuizTaken = view.findViewById(R.id.profile_taken_quiz)
        profileTotalQuizCreated = view.findViewById(R.id.profile_quiz_created)
        profileButton = view.findViewById(R.id.profile_button)
        profileImage = view.findViewById(R.id.profile_image)

        profileButton.setOnClickListener {
            navController.navigate(R.id.action_profileFragment_to_settingsFragment)
        }

        profileListViewModel = ViewModelProvider(requireActivity()).get(ProfileListViewModel::class.java)

        userId = firebaseAuth.currentUser?.uid!!

        firebaseFirestore.collection("quizlist").whereEqualTo("creator",userId).get().addOnSuccessListener {
            totalQuizCreated = it.size()
            profileTotalQuizCreated.text = "$totalQuizCreated"
        }

        firebaseFirestore.collection("users").document(userId).get()
            .addOnSuccessListener { document ->
                if (document != null) {
                    name = document["name"] as String? ?: "null"
                    email = document["email"] as String? ?: "null"
                    image = document["imageUrl"] as String? ?: "null"

                    profileName.text = name
                    profileEmail.text = email
                    Glide.with(requireContext()).load(image).into(profileImage!!)
                } else {
                    //Document doesn't exists
                    showToast(requireContext(), "Document doesn't exists...")
                }
            }.addOnFailureListener {
                //Handle the failure here
                showToast(requireContext(), "${it.message}")
            }

        firebaseFirestore.collection("users").document(userId).collection("Results").get()
            .addOnSuccessListener { snapshot ->
                val totalQuizTaken = snapshot.size()
                profileTotalQuizTaken.text = "$totalQuizTaken"

            }.addOnFailureListener {
                profileTotalQuizTaken.text = "${it.message}"
            }


        val query: Query = firebaseFirestore.collection("users").document(userId).collection("Results")

        //Update Ui
        val options = FirestoreRecyclerOptions.Builder<ProfileListModel>()
            .setLifecycleOwner(this)
            .setQuery(query, ProfileListModel::class.java)
            .build()

        profileListView.layoutManager = LinearLayoutManager(context)
        adapter = ResultRecyclerAdapter(options)
        profileListView.adapter = adapter

//        }
    }


    inner class ResultViewHolder internal constructor(private val view: View) :
        RecyclerView.ViewHolder(view) {
        internal fun setResultData(quizName: String?, _quizPercent: Long?, _quizId: String?, _quizImage: String?) {
            val quizTitle = view.findViewById<TextView>(R.id.profile_list_title)
            val quizScore = view.findViewById<TextView>(R.id.profile_list_score)
            val quizImage = view.findViewById<ImageView>(R.id.profile_list_image)

            quizId = _quizId ?: "null"
            quizTitle.text = quizName ?: "null"
            quizScore.text = "$_quizPercent %"
            if(_quizImage != "null") {
                Glide.with(view)
                    .load(_quizImage)
                    .placeholder(R.drawable.ic_launcher_background)
                    .into(quizImage)
            }
        }
    }

    private inner class ResultRecyclerAdapter internal constructor(options: FirestoreRecyclerOptions<ProfileListModel>) :
        FirestoreRecyclerAdapter<ProfileListModel, ResultViewHolder>(options) {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ResultViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.single_result_item, parent, false)
            return ResultViewHolder(view)
        }

        override fun onBindViewHolder(
            holder: ResultViewHolder,
            position: Int,
            model: ProfileListModel
        ) {
            holder.setResultData(model.quizTitle, model.quizScore, model.quiz_id, model.quizImage)
            holder.itemView.setOnClickListener {
                val newQuizId = model.quiz_id
                val action = ProfileFragmentDirections.actionProfileFragmentToResultFragment()
                action.quizId = newQuizId ?: "null"
                navController.navigate(action)
                Log.i(
                    "ProfileFragment",
                    "onBindViewHolder: You Clicked on $position : QuizId : $newQuizId : QuizImage ${model.quizImage}"
                )
            }
        }
    }
}


