package com.stdev.myquiz

import android.os.Bundle
import android.os.CountDownTimer
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.stdev.myquiz.models.QuestionModel
import com.stdev.myquiz.ui.calculator.CalculatorFragment
import com.stdev.myquiz.ui.showToast

class PracticeQuizFragment : Fragment(), View.OnClickListener {

    private lateinit var firebaseFirestore : FirebaseFirestore
    private lateinit var firebaseAuth : FirebaseAuth
    private lateinit var navController: NavController

    //Views
    private lateinit var practiceNumber : TextView
    private lateinit var practiceTimer : TextView
    private lateinit var practiceProgress : ProgressBar
    private lateinit var practiceQuestion : TextView
    private lateinit var practiceLayoutOne : LinearLayout
    private lateinit var practiceLayoutTwo : LinearLayout
    private lateinit var practiceLayoutThree : LinearLayout
    private lateinit var practiceLayoutFour : LinearLayout
    private lateinit var practiceLayoutFive : LinearLayout
    private lateinit var practiceOptionOne : TextView
    private lateinit var practiceOptionTwo : TextView
    private lateinit var practiceOptionThree : TextView
    private lateinit var practiceOptionFour : TextView
    private lateinit var practiceOptionFive : TextView
    private lateinit var practicePreviousButton : MaterialButton
    private lateinit var practiceNextButton : MaterialButton
    private lateinit var practiceAnswerButton : MaterialButton
    private lateinit var practiceSubmit : TextView
    private lateinit var practiceCalculator : ImageView
    private var countDownTimer : CountDownTimer? = null

    //Variables
    private var quizId = ""
    private var currentQuestion = 0
    private var currentUser = ""
    private var totalQuestionsToAnswer = 0L
    private var quizTime = 0L
    private var canAnswer = true
    private var allQuestionsList : List<QuestionModel> = ArrayList()
    private var answers : MutableList<Any?> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_practice_quiz, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        firebaseAuth = FirebaseAuth.getInstance()
        firebaseFirestore = FirebaseFirestore.getInstance()
        navController = Navigation.findNavController(view)

        (activity as AppCompatActivity).supportActionBar?.setDisplayHomeAsUpEnabled(false)

        //Initialize Views
        initViews(view)

        //Get Quiz stuffs
        currentUser = firebaseAuth.currentUser?.uid!!
        quizId = PracticeQuizFragmentArgs.fromBundle(requireArguments()).quizId
        totalQuestionsToAnswer = PracticeQuizFragmentArgs.fromBundle(requireArguments()).totalQuestions
        quizTime = PracticeQuizFragmentArgs.fromBundle(requireArguments()).quizTime

        getQuestions()

        startTimer()
        practiceProgress.max = allQuestionsList.size
        practiceProgress.progress = answers.size

        practiceLayoutOne.setOnClickListener(this)
        practiceLayoutTwo.setOnClickListener(this)
        practiceLayoutThree.setOnClickListener(this)
        practiceLayoutFour.setOnClickListener(this)
        practiceLayoutFive.setOnClickListener(this)
        practiceNextButton.setOnClickListener(this)
        practicePreviousButton.setOnClickListener(this)
        practiceCalculator.setOnClickListener(this)
        practiceSubmit.setOnClickListener(this)
        practiceAnswerButton.setOnClickListener(this)

        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner,object : OnBackPressedCallback(true){
            override fun handleOnBackPressed() {
                MaterialAlertDialogBuilder(requireContext())
                    .setMessage("Are you sure you want to Exit the Quiz ? ")
                    .setNegativeButton("Stay"){_,_->}
                    .setPositiveButton("Exit"){_,_->
                        navController.navigateUp()
                    }.show()
            }

        })

    }

    private fun startTimer() {
        countDownTimer = object : CountDownTimer(quizTime.times(60000),10){
            override fun onFinish() {
                context?.let{
                    canAnswer = false
                    submitExam()
                }
            }

            override fun onTick(millisUntilFinished: Long) {
                practiceTimer.text = "Time Left : ${millisUntilFinished / 1000}"
            }

        }
        countDownTimer?.start()
    }

    private fun submitExam(){
        var score = 0
        for(i in allQuestionsList.indices){
            if(answers[i]!= null && answers[i] == allQuestionsList[i].answer){
                score++
            }
        }
        val percent = (score * 100) / (allQuestionsList.size)
        var title = ""
        var message = ""
        var image = 0
        when {
            percent >= 80 -> {
                title = "Excellent !"
                message = "You Performed Excellently well.\nYou Scored $percent% \nKeep it Up"
                image = R.drawable.ic_quiz
            }
            percent in 70..79 -> {
                title = "Very Good !"
                message = "You did great ! \nYou Scored $percent% \nKeep it Up"
                image = R.drawable.ic_quiz
            }
            percent in 60..69 -> {
                title = "Good !"
                message = "You did well ! \nYou Scored $percent% \nKeep Learning "
                image = R.drawable.ic_quiz
            }
            percent in 50..59 -> {
                title = "You Tried"
                message = "You tried your best ! \nYou Scored $percent% \nKeep pushing and learning and try again some other time"
                image = R.drawable.ic_add
            }
            percent in 0..49 -> {
                title = "You didn\'t do so well"
                message = "You tried your best ! \nYou Scored $percent% \nDon\'t be discouraged , Keep pushing and learning and try again some other time"
                image = R.drawable.ic_delete
            }
        }

        MaterialAlertDialogBuilder(requireContext())
            .setIcon(image)
            .setTitle(title)
            .setMessage(message)
            .setNegativeButton("Exit"){_,_->
                navController.navigateUp()
            }
            .setPositiveButton("Check Answers"){_,_->
                canAnswer = false
                countDownTimer?.cancel()
                practiceSubmit.text = "Exit"
                practiceAnswerButton.visibility = View.VISIBLE
            }.show()
        showToast(requireContext(),"Correct Score -> $score")
    }

    private fun getQuestions() {
        if(totalQuestionsToAnswer != 0L){
            firebaseFirestore.collection("quizlist").document(quizId).collection("Questions").get()
                .addOnSuccessListener {
                    allQuestionsList = it.toObjects(QuestionModel::class.java)
                    answers = allQuestionsList.toMutableList()

                    loadQuestion(1)
                }.addOnFailureListener {
                    showToast(requireContext(),"Error Getting the Quiz -> ${it.message}")
                }
        }else{
            showToast(requireContext(), "Error Retrieving Quiz")
        }
    }

    private fun loadQuestion(questionNumber: Int) {
        ///Set Question Number
        practiceNumber.text = "Question $questionNumber / ${allQuestionsList.size}"
        //Load Question
        practiceQuestion.text = allQuestionsList[questionNumber -1].question
        practiceOptionOne.text = allQuestionsList[questionNumber -1].option_a
        practiceOptionTwo.text = allQuestionsList[questionNumber -1].option_b

        val option_c = allQuestionsList[questionNumber -1].option_c
        val option_d = allQuestionsList[questionNumber -1].option_d
        val option_e = allQuestionsList[questionNumber -1].option_e

        if(option_c == "null" || option_c =="" || option_c.isNullOrEmpty()){
            practiceOptionThree.visibility = View.INVISIBLE
            practiceLayoutThree.visibility = View.INVISIBLE
        }else {
            practiceOptionThree.visibility = View.VISIBLE
            practiceLayoutThree.visibility = View.VISIBLE
            practiceOptionThree.text = option_c
        }

        if(option_d == "null" || option_d =="" || option_d.isNullOrEmpty()){
            practiceOptionFour.visibility = View.INVISIBLE
            practiceLayoutFour.visibility = View.INVISIBLE
        }else {
            practiceOptionFour.visibility = View.VISIBLE
            practiceLayoutFour.visibility = View.VISIBLE
            practiceOptionFour.text = option_d
        }

        if(option_e == "null" || option_e =="" || option_e.isNullOrEmpty()){
            practiceOptionFive.visibility = View.INVISIBLE
            practiceLayoutFive.visibility = View.INVISIBLE
        }else {
            practiceOptionFive.visibility = View.VISIBLE
            practiceLayoutFive.visibility = View.VISIBLE
            practiceOptionFive.text = option_e
        }

        currentQuestion = questionNumber
        if(currentQuestion == totalQuestionsToAnswer.toInt()){
            if(canAnswer) {
                practiceNextButton.text = "Finish"
            }else{
                practiceNextButton.text = "Exit"
            }
        }else {
            practiceNextButton.text = "Next"
        }
    }

    private fun initViews(view: View) {
        practiceNumber = view.findViewById(R.id.practice_number)
        practiceQuestion = view.findViewById(R.id.practice_question)
        practiceTimer = view.findViewById(R.id.practice_timer)
        practiceProgress = view.findViewById(R.id.practice_progress)
        practiceLayoutOne = view.findViewById(R.id.practice_layout_one)
        practiceLayoutTwo = view.findViewById(R.id.practice_layout_two)
        practiceLayoutThree = view.findViewById(R.id.practice_layout_three)
        practiceLayoutFour = view.findViewById(R.id.practice_layout_four)
        practiceLayoutFive = view.findViewById(R.id.practice_layout_five)
        practiceOptionOne = view.findViewById(R.id.practice_option_one)
        practiceOptionTwo = view.findViewById(R.id.practice_option_two)
        practiceOptionThree = view.findViewById(R.id.practice_option_three)
        practiceOptionFour = view.findViewById(R.id.practice_option_four)
        practiceOptionFive = view.findViewById(R.id.practice_option_five)
        practicePreviousButton = view.findViewById(R.id.practice_previous_button)
        practiceNextButton = view.findViewById(R.id.practice_next_button)
        practiceAnswerButton = view.findViewById(R.id.practice_answer_button)
        practiceSubmit = view.findViewById(R.id.practice_submit)
        practiceCalculator = view.findViewById(R.id.practice_calculator)

    }

    override fun onClick(v: View?) {
        when(v?.id){
            R.id.practice_submit -> {
                if(canAnswer) {
                    MaterialAlertDialogBuilder(requireContext())
                        .setMessage("Are you sure you want to submit")
                        .setNegativeButton("No") { _, _ -> }
                        .setPositiveButton("Yes") { _, _ ->
                            canAnswer = false
                            submitExam()
                        }.show()
                }else {
                    navController.navigateUp()
                }
            }
            R.id.practice_calculator -> {
                val dialog = CalculatorFragment()
                dialog.show(childFragmentManager,"calculatorFragment2")
            }
            R.id.practice_next_button -> {
                if(currentQuestion == totalQuestionsToAnswer.toInt()){
                    if(canAnswer) {
                        MaterialAlertDialogBuilder(requireContext())
                            .setMessage("Are you sure you want to submit ? ")
                            .setNegativeButton("No") { _, _ -> }
                            .setPositiveButton("Yes") { _, _ ->
                                canAnswer = false
                                submitExam()
                            }.show()
                    }else{
                        navController.navigateUp()
                    }
                } else{
                    currentQuestion++
                    clearStuffs()
                    loadQuestion(currentQuestion)
                    checkStuffs(currentQuestion)
                }
            }
            R.id.practice_previous_button -> {
                if(currentQuestion != 1){
                    currentQuestion--
                    loadQuestion(currentQuestion)
                    checkStuffs(currentQuestion)
                }
            }
            R.id.practice_answer_button -> {
                val description = allQuestionsList[currentQuestion-1].description
                val title = if(answers[currentQuestion-1]!= null && answers[currentQuestion-1] == allQuestionsList[currentQuestion-1].answer){
                    "Correct"
                }else{
                    "Wrong"
                }
                MaterialAlertDialogBuilder(requireContext())
                    .setTitle(title)
                    .setMessage("$description")
                    .show()
            }
            R.id.practice_layout_one -> {
                if(canAnswer) {
                    answers[currentQuestion - 1] = "${practiceOptionOne.text}"
                    practiceLayoutOne.background = resources.getDrawable(R.drawable.option_selected, null)
                    practiceLayoutTwo.background = resources.getDrawable(R.drawable.option_unselected, null)
                    practiceLayoutThree.background = resources.getDrawable(R.drawable.option_unselected, null)
                    practiceLayoutFour.background = resources.getDrawable(R.drawable.option_unselected, null)
                    practiceLayoutFive.background = resources.getDrawable(R.drawable.option_unselected, null)
                }
            }
            R.id.practice_layout_two -> {
                if(canAnswer) {
                    answers[currentQuestion - 1] = "${practiceOptionTwo.text}"
                    practiceLayoutOne.background =
                        resources.getDrawable(R.drawable.option_unselected, null)
                    practiceLayoutTwo.background =
                        resources.getDrawable(R.drawable.option_selected, null)
                    practiceLayoutThree.background =
                        resources.getDrawable(R.drawable.option_unselected, null)
                    practiceLayoutFour.background =
                        resources.getDrawable(R.drawable.option_unselected, null)
                    practiceLayoutFive.background =
                        resources.getDrawable(R.drawable.option_unselected, null)
                }
            }
            R.id.practice_layout_three -> {
                if (canAnswer) {
                    answers[currentQuestion - 1] = "${practiceOptionThree.text}"
                    practiceLayoutOne.background =
                        resources.getDrawable(R.drawable.option_unselected, null)
                    practiceLayoutTwo.background =
                        resources.getDrawable(R.drawable.option_unselected, null)
                    practiceLayoutThree.background =
                        resources.getDrawable(R.drawable.option_selected, null)
                    practiceLayoutFour.background =
                        resources.getDrawable(R.drawable.option_unselected, null)
                    practiceLayoutFive.background =
                        resources.getDrawable(R.drawable.option_unselected, null)
                }
            }
            R.id.practice_layout_four -> {
                if(canAnswer) {
                    answers[currentQuestion - 1] = "${practiceOptionFour.text}"
                    practiceLayoutOne.background =
                        resources.getDrawable(R.drawable.option_unselected, null)
                    practiceLayoutTwo.background =
                        resources.getDrawable(R.drawable.option_unselected, null)
                    practiceLayoutThree.background =
                        resources.getDrawable(R.drawable.option_unselected, null)
                    practiceLayoutFour.background =
                        resources.getDrawable(R.drawable.option_selected, null)
                    practiceLayoutFive.background =
                        resources.getDrawable(R.drawable.option_unselected, null)
                }
            }
            R.id.practice_layout_five ->{
                if(canAnswer) {
                    answers[currentQuestion - 1] = "${practiceOptionFive.text}"
                    practiceLayoutOne.background =
                        resources.getDrawable(R.drawable.option_unselected, null)
                    practiceLayoutTwo.background =
                        resources.getDrawable(R.drawable.option_unselected, null)
                    practiceLayoutThree.background =
                        resources.getDrawable(R.drawable.option_unselected, null)
                    practiceLayoutFour.background =
                        resources.getDrawable(R.drawable.option_unselected, null)
                    practiceLayoutFive.background =
                        resources.getDrawable(R.drawable.option_selected, null)

                }

            }
        }
    }

    private fun checkStuffs(number : Int) {
        when {
            answers.getOrNull(number -1) == true -> {
                practiceLayoutOne.background = resources.getDrawable(R.drawable.option_unselected,null)
                practiceLayoutTwo.background = resources.getDrawable(R.drawable.option_unselected,null)
                practiceLayoutThree.background = resources.getDrawable(R.drawable.option_unselected,null)
                practiceLayoutFour.background = resources.getDrawable(R.drawable.option_unselected,null)
                practiceLayoutFive.background = resources.getDrawable(R.drawable.option_unselected,null)
            }
            answers[number -1] == practiceOptionOne.text -> {
                practiceLayoutOne.background = resources.getDrawable(R.drawable.option_selected,null)
                practiceLayoutTwo.background = resources.getDrawable(R.drawable.option_unselected,null)
                practiceLayoutThree.background = resources.getDrawable(R.drawable.option_unselected,null)
                practiceLayoutFour.background = resources.getDrawable(R.drawable.option_unselected,null)
                practiceLayoutFive.background = resources.getDrawable(R.drawable.option_unselected,null)
            }
            answers[number -1] == practiceOptionTwo.text -> {
                practiceLayoutOne.background = resources.getDrawable(R.drawable.option_unselected,null)
                practiceLayoutTwo.background = resources.getDrawable(R.drawable.option_selected,null)
                practiceLayoutThree.background = resources.getDrawable(R.drawable.option_unselected,null)
                practiceLayoutFour.background = resources.getDrawable(R.drawable.option_unselected,null)
                practiceLayoutFive.background = resources.getDrawable(R.drawable.option_unselected,null)
            }
            answers[number -1] == practiceOptionThree.text -> {
                practiceLayoutOne.background = resources.getDrawable(R.drawable.option_unselected,null)
                practiceLayoutTwo.background = resources.getDrawable(R.drawable.option_unselected,null)
                practiceLayoutThree.background = resources.getDrawable(R.drawable.option_selected,null)
                practiceLayoutFour.background = resources.getDrawable(R.drawable.option_unselected,null)
                practiceLayoutFive.background = resources.getDrawable(R.drawable.option_unselected,null)
            }
            answers[number -1] == practiceOptionFour.text -> {
                practiceLayoutOne.background = resources.getDrawable(R.drawable.option_unselected,null)
                practiceLayoutTwo.background = resources.getDrawable(R.drawable.option_unselected,null)
                practiceLayoutThree.background = resources.getDrawable(R.drawable.option_unselected,null)
                practiceLayoutFour.background = resources.getDrawable(R.drawable.option_selected,null)
                practiceLayoutFive.background = resources.getDrawable(R.drawable.option_unselected,null)
            }
            answers[number -1] == practiceOptionFive.text -> {
                practiceLayoutOne.background = resources.getDrawable(R.drawable.option_unselected,null)
                practiceLayoutTwo.background = resources.getDrawable(R.drawable.option_unselected,null)
                practiceLayoutThree.background = resources.getDrawable(R.drawable.option_unselected,null)
                practiceLayoutFour.background = resources.getDrawable(R.drawable.option_unselected,null)
                practiceLayoutFive.background = resources.getDrawable(R.drawable.option_selected,null)
            }
        }
    }

    private fun clearStuffs() {
        practiceLayoutOne.background = resources.getDrawable(R.drawable.option_unselected,null)
        practiceLayoutTwo.background = resources.getDrawable(R.drawable.option_unselected,null)
        practiceLayoutThree.background = resources.getDrawable(R.drawable.option_unselected,null)
        practiceLayoutFour.background = resources.getDrawable(R.drawable.option_unselected,null)
        practiceLayoutFive.background = resources.getDrawable(R.drawable.option_unselected,null)

    }

    override fun onResume() {
        super.onResume()
        (activity as AppCompatActivity).supportActionBar?.hide()
    }

    override fun onStop() {
        super.onStop()
        (activity as AppCompatActivity).supportActionBar?.show()
    }

}